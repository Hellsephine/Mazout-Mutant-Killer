package mmk.model.action;

import mmk.model.personnage.Character;
import mmk.model.personnage.state.EPersonnageState;
import mmk.model.world.Board;

public class Block implements IAction {

    @Override
    public void doo(Character personnage, Board board, int... args) {
        personnage.getStats().addCharacterState(EPersonnageState.BLOCK, 1);
    }
}
