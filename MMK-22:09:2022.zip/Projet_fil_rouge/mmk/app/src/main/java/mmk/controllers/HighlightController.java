package mmk.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class HighlightController {
    
}
