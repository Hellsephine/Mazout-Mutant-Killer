package mmk.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mmk.dao.StaticCharacterRepository;
import mmk.exceptions.StaticCharacterNotFoundException;
import mmk.model.personnage.StaticCharacter;

@Service
public class StaticCharacterServices {
    
    @Autowired
    private StaticCharacterRepository staticCharacterRepository;

    public List<StaticCharacter> getStaticCharacterByType()
    {
        return staticCharacterRepository.findByType(0);
    }

    public StaticCharacter getStaticCharacterById(int id) throws StaticCharacterNotFoundException
    {
        Optional<StaticCharacter> staticCharacter = staticCharacterRepository.findById(id);
        if(staticCharacter.isPresent()){
            StaticCharacter staticCharacter2 = staticCharacter.get();
            return staticCharacter2;
        }
        else{
            throw new StaticCharacterNotFoundException(); 
        }
        
    }

}
