package mmk.model.action;

import mmk.model.personnage.Character;
import mmk.model.world.Board;

public class Jump implements IAction {





    @Override
    public void doo(Character c, Board board, int... args) {
        board.move(c.getStats().getPosition(), c.getStats().getPosition().add(c.getStats().getDirection().add(c.getStats().getDirection())));
    }
}
