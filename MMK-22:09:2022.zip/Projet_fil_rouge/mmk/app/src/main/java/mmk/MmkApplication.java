package mmk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MmkApplication{
	public static void main(String[] args) {
		SpringApplication.run(MmkApplication.class, args);
	}

}