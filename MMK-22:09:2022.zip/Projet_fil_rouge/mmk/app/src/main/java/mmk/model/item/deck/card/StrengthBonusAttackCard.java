package mmk.model.item.deck.card;

import mmk.model.personnage.Character;
import mmk.model.world.Board;

/**
 * Carte qui donne un Pa si nous avons suffisament de Force
 */
public class StrengthBonusAttackCard extends ACard {

    public StrengthBonusAttackCard() {
        super(8);
    }

    public void effect(Board board, int nbTours) {
        for (Character hero : board.getHeros()) {
            if(hero.getStats().getStrength() > 20){
                hero.getStats().addPa(1);
            }
        }
    }

}
