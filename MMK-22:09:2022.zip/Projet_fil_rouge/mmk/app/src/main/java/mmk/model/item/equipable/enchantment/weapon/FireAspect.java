package mmk.model.item.equipable.enchantment.weapon;

import mmk.model.item.equipable.enchantment.IEnchantment;
import mmk.model.personnage.Character;

import mmk.model.personnage.state.EPersonnageState;


/**
 * représente l'enchangement fireAspect, qui met en feu la personne touché (ajoute des dégat au coup donné)
 */
public class FireAspect extends AEnchantmentWeapon {

    private static final int idEnchantment = 1;

    /**
     * constructeur de FireAspect
     * @param weapon l'arme à enchanter
     */
    public FireAspect(IEnchantment weapon) {
        super(weapon);
    }

    @Override
    public int use(Character character, int degattheorique) {
        degattheorique = degattheorique + 5;
        character.addPersonnageState(EPersonnageState.BURN, 3);
        return super.use(character, degattheorique);
    }

    @Override
    public String getName() {
        return super.getName() + " avec l'enchantement FireAspect";
    }
    @Override
    public String getDescription() {
        return super.getDescription() + " avec l'enchantment FireAspect";
    }
    @Override
    public String getIconURL() {
        return super.getIconURL();
    }
    @Override
    public int getMinRange() {
        return super.getMinRange();
    }
    @Override
    public int getMaxRange() {
        return super.getMaxRange();
    }
    @Override
    public int getDamage() {
        return super.getDamage();
    }

}
