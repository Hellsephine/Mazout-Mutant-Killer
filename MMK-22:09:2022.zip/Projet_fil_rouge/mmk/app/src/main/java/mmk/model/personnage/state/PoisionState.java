package mmk.model.personnage.state;

import mmk.model.personnage.Character;

public class PoisionState extends APersonnageState{


    public PoisionState(int duration) {
        super(duration);
    }

    @Override
    public boolean effect(Character c) {
        c.getStats().removeHp(1);

        return --this.duration == 0;
    }


}
