package mmk;


import mmk.controllers.TerminalController;
import mmk.model.personnage.state.PersonnageStateManager;
import mmk.model.util.DBConnection;
import mmk.model.util.eventmanagement.EEventType;
import mmk.model.util.eventmanagement.EventManager;
import mmk.model.world.Save;
import mmk.view.TerminalView;

public class App {

    public static void main(String[] args) {

        Save modelAction = DBConnection.SESSION.getReference(Save.class, 1);
        TerminalController controller = new TerminalController(modelAction);
        TerminalView view = new TerminalView(controller);

        EventManager.EVENT_MANAGER.subscribe(EEventType.MODIFY_APERSONNAGE_BOARD, view);
        EventManager.EVENT_MANAGER.subscribe(EEventType.ASK_TERMINAL_INPUT, view);
        EventManager.EVENT_MANAGER.subscribe(EEventType.GET_HIT, view);
        EventManager.EVENT_MANAGER.subscribe(EEventType.ATTACK, view);

        EventManager.EVENT_MANAGER.subscribe(EEventType.NEW_PERSONNAGE_STATE, PersonnageStateManager.PERSONNAGE_STATE_MANAGER);

        modelAction.notifyNew();
        modelAction.effectCard();
        System.out.println("pa : " +modelAction.getHero().getStats().getCurrentPa() + ", pm : " + modelAction.getHero().getStats().getCurrentPm());
        System.out.println("1 : move, 2 : attaquer, 3 : consomer, 4 : block, 5 : jump, -11 : fin tour");
        view.getInput();

    }
}
