package mmk.services;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysql.cj.x.protobuf.MysqlxCrud.Collection;

import mmk.dao.StaticArmorRepository;
import mmk.dao.StaticCharacterRepository;
import mmk.dao.StaticWeaponRepository;
import mmk.model.item.equipable.armor.StaticArmor;
import mmk.model.item.equipable.weapon.StaticWeapon;
import mmk.model.personnage.StaticCharacter;

@Service
public class HighlightArticlesServices {
    
    @Autowired
    private StaticArmorRepository staticArmorRepository;

    @Autowired
    private StaticWeaponRepository staticWeaponRepository;

    @Autowired
    private StaticCharacterRepository staticCharacterRepository;

    public List<Object> getHighlight(){

        List<Object> mainHighlight = new ArrayList<Object>(5);
        List<StaticArmor> staticArmor = staticArmorRepository.findByStaticItem_PriceGreaterThan(0);
        List<StaticWeapon> staticWeapon = staticWeaponRepository.findByStaticItem_PriceGreaterThan(0);
        List<StaticCharacter> staticCharacter = staticCharacterRepository.findByType(0);
        
        Random r = new Random();
       
        int n = r.nextInt(2)+1;
        int m = r.nextInt(2)+1;

        for(int i=0; i< n;i++){
            int x = r.nextInt(staticArmor.size());
            mainHighlight.add(staticArmor.get(x));
        }
        for(int i=0; i< m;i++){
            int y = r.nextInt(staticWeapon.size());
            mainHighlight.add(staticWeapon.get(y));
        }
        for(int i=0; i<5-n-m; i++){
            int z = r.nextInt(staticCharacter.size());
            mainHighlight.add(staticCharacter.get(z));
        }
        return mainHighlight;
    }
}
