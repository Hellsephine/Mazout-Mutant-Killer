package mmk.model.item.equipable.weapon;

import javax.persistence.*;
import mmk.model.item.StaticItem;
import mmk.model.item.equipable.IEquipable;
import mmk.model.personnage.Character;
import mmk.model.util.DBConnection;

/**
 * classe représentant une arme
 */
@Entity
@Table(name = "weapon")
public class Weapon implements IEquipable {

    //#region attribut
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_item")
    private StaticItem staticItem;

    @Column(name="damage")
    private Integer damage;

    @Column(name = "max_range")
    protected Integer maxRange;

    @Column(name = "min_range")
    protected Integer minRange;

    @Column(name ="enchantment")
    private Integer enchantment;
    //#endregion

    public Weapon() {}

    public Weapon(int idStaticWeapon, float damageMultiplier, int enchantment) {
        StaticWeapon staticWeapon = DBConnection.SESSION.getReference(StaticWeapon.class, idStaticWeapon);

        this.staticItem = staticWeapon.getStaticItem();
        this.damage = (int) Math.floor(staticWeapon.getDamage()*damageMultiplier);
        this.minRange = staticWeapon.getMinRange();
        this.maxRange = staticWeapon.getMaxRange();
        this.enchantment = enchantment;
    }
    @Override
    public void equip(Character target) {
        target.setWeapon(this);
    }

    @Override
    public void unequip(Character target) {
        target.setWeapon(DBConnection.SESSION.getReference(Weapon.class, 1)); // TODO changer ça
    }

    @Override
    public int use(Character personnage, int degattheorique) {
        return degattheorique+damage;
    }

    @Override
    public boolean equals(Object o){
        if (!(o instanceof Weapon w))
            return false;

        if (this.getDamage() != w.getDamage())
            return false;
        if (this.getMaxRange() != w.getMaxRange())
            return false;
        if(this.getMinRange() != w.getMinRange())
            return false;
        if (!this.enchantment.equals(w.enchantment))
            return false;
        if (!this.staticItem.equals(w.staticItem))
            return false;

        return true;
    }

    //#region Getter et Setter
    public void addEnchantment(int enchantment) {
        this.enchantment = this.enchantment|enchantment;
    }

    public Integer getId() {
        return id;
    }

    public StaticItem getStaticItem() {
        return staticItem;
    }

    public Integer getEnchantment() {
        return enchantment;
    }

    public Integer getDamage() {
        return damage;
    }

    public void setDamage(Integer damage) {
        this.damage = damage;
    }

    public Integer getMaxRange() {
        return maxRange;
    }

    public void setMax_range(Integer max_range) {
        this.maxRange = max_range;
    }

    public Integer getMinRange() {
        return minRange;
    }

    public void setMinRange(Integer min_range) {
        this.minRange = min_range;
    }
    //#endregion
}
