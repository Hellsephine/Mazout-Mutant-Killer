package mmk.model.item.deck.card;

import mmk.model.personnage.Character;
import mmk.model.world.Board;
/**
 * Carte qui donne une regeneration de pv si la force est suffisante
 */
public class StrengthForHealingCard extends ACard {

    public StrengthForHealingCard() {
        super(6);
    }

    public void effect(Board board, int nbTours) {
        if (nbTours != 0) {
            for (Character hero : board.getHeros()) {
                if(hero.getStats().getStrength() > 20 && hero.getStats().getHp() < hero.getStats().getMaxHp()){
                    hero.getStats().addHp(2);
                }
            }
        }
    }

}
