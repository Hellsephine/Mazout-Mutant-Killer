package mmk.model.item.deck.card;

import mmk.model.personnage.Character;
import mmk.model.world.Board;

/**
 *  carte qui augment la force d'une valeur fixe
 */
public class StrengthCard extends ACard {

    public StrengthCard() {
        super(5);
    }

    public void effect(Board board, int nbTours) {
        for (Character hero : board.getHeros())
            hero.getStats().addStrength(5);
    }

}
