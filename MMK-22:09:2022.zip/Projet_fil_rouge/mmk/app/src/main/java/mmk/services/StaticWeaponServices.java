package mmk.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mmk.dao.StaticWeaponRepository;
import mmk.exceptions.StaticWeaponNotFoundException;
import mmk.model.item.equipable.weapon.StaticWeapon;

@Service
public class StaticWeaponServices {
    
    @Autowired
    private StaticWeaponRepository staticWeaponRepository;

    public StaticWeapon getStaticWeaponById(int id) throws StaticWeaponNotFoundException
    {
        Optional<StaticWeapon> staticWeapon = staticWeaponRepository.findById(id);
        if(staticWeapon.isPresent()){
            StaticWeapon staticWeapon2 = staticWeapon.get();
            return staticWeapon2;
        }
        else{
            throw new StaticWeaponNotFoundException();
        }
   }

   public List<StaticWeapon> getStaticWeaponByStaticItem_PriceGreaterThan(int price) throws StaticWeaponNotFoundException
    {
        List<StaticWeapon> staticWeapon = staticWeaponRepository.findByStaticItem_PriceGreaterThan(price);
        if(staticWeapon != null){
            return staticWeapon;
        }
        else{
            throw new StaticWeaponNotFoundException();
        }
    }
}

