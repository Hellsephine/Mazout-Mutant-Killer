package mmk.model.item.deck.card;

import mmk.model.personnage.Character;
import mmk.model.world.Board;


public class RegenHpCard extends ACard {


    private boolean used = false;

    public RegenHpCard() {
        super(1);
    }

    public void effect(Board board, int nbTours) {
        if(!this.used){
            for (Character hero : board.getHeros()){
                if(hero.getStats().getHp() < hero.getStats().getMaxHp()*(30/100.0f)){
                    hero.getStats().addHp((int) (hero.getStats().getMaxHp()*(20/100.0f)));
                }
            }
            this.used = true;
        }
    }
}
