package mmk.model.item.equipable.armor;

import javax.persistence.*;
import mmk.model.item.StaticItem;

import mmk.model.item.equipable.IEquipable;
import mmk.model.personnage.Character;
import mmk.model.util.DBConnection;

/**
 * classe représentant une armure
 */
@Entity
@Table(name = "armor")
public class Armor implements IEquipable {

    //#region attributs
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "id_item")
    private StaticItem staticItem;

    @Column(name = "defence")
    private Integer defence;

    @Column(name = "enchantment")
    private Integer enchantment;
    //#endregion


    public Armor() {}

    public Armor(int idStaticArmor, float defenceMultiplier, int enchantment) {
        StaticArmor staticArmor = DBConnection.SESSION.getReference(StaticArmor.class, idStaticArmor);

        this.staticItem = staticArmor.getStaticItem();
        this.defence = (int) Math.floor(staticArmor.getDefence()*defenceMultiplier);
        this.enchantment = enchantment;
    }

    @Override
    public void equip(Character target) {
        target.setArmor(this);
    }

    @Override
    public void unequip(Character target) {
        target.setArmor(DBConnection.SESSION.getReference(Armor.class, 1)); // TODO changer ça
    }

    @Override
    public int use(Character personnage, int degattheorique) {
        return degattheorique-defence;
    }

    @Override
    public boolean equals(Object o){
        if (!(o instanceof Armor a))
            return false;

        if (this.getDefence() != a.getDefence())
            return false;
        if (!this.enchantment.equals(a.enchantment))
            return false;
        if (!this.staticItem.equals(a.staticItem))
            return false;

        return true;
    }

    //#region Getter/Setter
    public void addEnchantment(int enchantment) {
        this.enchantment = this.enchantment|enchantment;
    }
    public int getDefence() {
        return defence;
    }
    public void setDefence(int defence) {
        this.defence = defence;
    }
    public StaticItem getStaticItem() {
        return this.staticItem;
    }
    //#endregion
    
   
}
