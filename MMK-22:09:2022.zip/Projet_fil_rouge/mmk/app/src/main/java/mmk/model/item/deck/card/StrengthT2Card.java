package mmk.model.item.deck.card;

import mmk.model.personnage.Character;
import mmk.model.world.Board;

/**
 * carte qui augment la force pendant 2 tours
 */
public class StrengthT2Card extends ACard {

    public StrengthT2Card() {
        super(3);
    }


    public void effect(Board board, int nbTours) {
        int strengthBonus = 5;
        if (nbTours == 0) {
            for (Character hero : board.getHeros()) {
                hero.getStats().addStrength(strengthBonus);
            }
        }
        if (nbTours == 2) {
            for (Character hero : board.getHeros()) {
                hero.getStats().removeStrength(strengthBonus);
            }
        }
    }
}
