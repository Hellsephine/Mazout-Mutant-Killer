package mmk.model.personnage;

import javax.persistence.*;
import mmk.model.action.EActionState;
import mmk.model.item.Inventory;
import mmk.model.item.equipable.armor.Armor;
import mmk.model.item.equipable.weapon.Weapon;
import mmk.model.personnage.state.EPersonnageState;
import mmk.model.util.eventmanagement.EEventType;
import mmk.model.util.eventmanagement.EventManager;
import mmk.model.world.Board;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * classe abstraite représantant la base d'un character
 */
@Entity
@Table(name = "character")
public class Character {


    //#region attributs
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "id_character")
    private StaticCharacter staticCharacter;

    @OneToOne
    @JoinColumn(name = "id_stats")
    private Stats stats;

    @OneToOne
    @JoinColumn(name = "id_weapon")
    private Weapon weapon;

    @OneToOne
    @JoinColumn(name = "id_armor")
    private Armor armor;

    @OneToMany
    @JoinColumn(name = "id_character")
    private Set<Inventory> inventoryList; // TODO trouver un moyen de gerer ça

    @Transient
    private final List<EActionState> actionState = new ArrayList<>();
    //#endregion

    //#region constructor
    public Character() {}

    public Character(StaticCharacter staticCharacter, Stats stats, Weapon weapon, Armor armor) {
        this.staticCharacter = staticCharacter;
        this.weapon = weapon;
        this.armor = armor;
        this.stats = stats;
    }
    //#endregion

    /**
     * renvoie vrai si le character est mort, faux sinon
     * @return vrai si le character est mort, faux sinon
     */
    public boolean isDead() {
        return this.getStats().getHp() <= 0;
    }

    /**
     * permet au character d'attaquer
     * @param board le plateau dans le quel le personnage evolue
     */
    public void attack(Board board) {
        Character target = board.getInRange(this);

        if(target == null)
            return ;


        int degat = this.getWeapon().use(target, 0);
        degat += this.getStats().getStrength();

        target.takeDomage(this, degat);
    }

    /**
     * permet au personnage de prendre des degats
     * @param amount la quantité de dégats entrant
     */
    public void takeDomage(Character attacker, int amount) {
        int degat = this.getArmor().use(attacker, amount);

        if(this.getStats().hasPersonnageState(EPersonnageState.BLOCK))
            degat *= 0.8f;

        if(degat>0){
            this.getStats().removeHp(degat);
            EventManager.EVENT_MANAGER.notify(EEventType.GET_HIT, this);
        }

    }

    public int getType() {
        if (this.inventoryList != null)
            return 1;
        return 2;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Character personnage))
            return false;

        if (!this.getStats().equals(personnage.getStats()))
            return false;
        if (!this.getStaticPersonnage().equals(personnage.getStaticPersonnage()))
            return false;
        if (!personnage.weapon.equals(this.weapon))
            return false;
        if (!personnage.armor.equals(this.armor))
            return false;
        // TODO equals actionsState
        /*
        if (personnage.getActionState(). this.getActionState())
            return false;*/

        return true;
    }

    @Override
    public int hashCode() {
        double hash = (Math.log10(this.getId())+1)*10;
        hash *=  this.getType();
        hash += this.getId();
        return (int) hash;
    }

    //#region adder/remover
    public int addActionState(EActionState actionState) {
        if (actionState.isPa()) {
            if (this.getStats().getCurrentPa() >= actionState.getAmount()) {
                this.actionState.add(actionState);
                this.getStats().removeCurrentPa(actionState.getAmount());
            }
            return this.getStats().getCurrentPa();
        } else {
            if (this.getStats().getCurrentPm() >= actionState.getAmount()) {
                this.actionState.add(actionState);
                this.getStats().removeCurrentPm(actionState.getAmount());
            }
            return this.getStats().getCurrentPm();
        }
    }
    public void resetActionState() {
        this.actionState.clear();
    }
    public void addInventory(Inventory inventory) {
        this.inventoryList.add(inventory);
    }
    //endregion

    //#region getter/setter
    public Integer getId() {
        return id;
    }

    public StaticCharacter getStaticPersonnage() {
        return staticCharacter;
    }

    public Stats getStats() {
        return stats;
    }

    public Weapon getWeapon() {
        return weapon;
    }

    public void setWeapon(Weapon weapon) {
        this.weapon = weapon;
    }

    public Armor getArmor() {
        return armor;
    }

    public void setArmor(Armor armor) {
        this.armor = armor;
    }

    public EActionState[] getActionState() {
        return actionState.toArray(EActionState[]::new);
    }

    public Set<Inventory> getInventory() {
        return this.inventoryList;
    }
    //#endregion
}