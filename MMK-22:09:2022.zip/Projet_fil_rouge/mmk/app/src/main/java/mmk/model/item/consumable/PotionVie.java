package mmk.model.item.consumable;

import mmk.model.personnage.Character;

/**
 * représente la Potion de vie, qui permet de regagner des Hp
 */
public class PotionVie extends AConsumable {
    
    protected PotionVie() {
        super(22);
    }

    @Override
    public void consume(Character c) {
        c.getStats().addHp(10);
    }
    
}
