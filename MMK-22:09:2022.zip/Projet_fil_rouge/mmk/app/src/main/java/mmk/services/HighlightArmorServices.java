package mmk.services;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mmk.dao.StaticArmorRepository;
import mmk.model.item.equipable.armor.StaticArmor;

@Service
public class HighlightArmorServices {
    
    @Autowired
    private StaticArmorRepository staticArmorRepository;

    public List<StaticArmor> getStaticArmorByRandomHighlight()
    {
        List<StaticArmor> staticArmor = staticArmorRepository.findByStaticItem_PriceGreaterThan(0);
        Collections.shuffle(staticArmor);

        int NbrHighlight = 3;

        List<StaticArmor> HightlightArmor = staticArmor.subList(0, NbrHighlight);

        return HightlightArmor;
    }
}
