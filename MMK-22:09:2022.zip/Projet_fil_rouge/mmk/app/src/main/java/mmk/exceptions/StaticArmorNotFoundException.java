package mmk.exceptions;

public class StaticArmorNotFoundException extends Exception {
    
}
