package mmk.model.item.deck.card;

import mmk.model.personnage.Character;
import mmk.model.world.Board;

/**
 *  carte qui augment la force pendant les tours paires
 */
public class StrengthPairCard extends ACard {


    public StrengthPairCard() {
        super(4);
    }

    public void effect(Board board, int nbTours) {
        int strengthBonus = 5;
        if (nbTours % 2 == 0) {
            for (Character hero : board.getHeros()) {
                hero.getStats().addStrength(strengthBonus);
            }
        }
        else{
            for(Character hero: board.getHeros()){
                hero.getStats().removeStrength(strengthBonus);
            }
        }
    }
}