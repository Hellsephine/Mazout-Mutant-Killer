package mmk.model.personnage.state;

import mmk.model.personnage.Character;
import mmk.model.util.eventmanagement.EEventType;
import mmk.model.util.eventmanagement.EventListener;
import mmk.model.world.Board;

import java.util.HashMap;

public class PersonnageStateManager implements EventListener {

    public static final PersonnageStateManager PERSONNAGE_STATE_MANAGER = new PersonnageStateManager();

    private HashMap<Character, APersonnageState[]> states;

    private PersonnageStateManager() {
            this.states = new HashMap<>();
    }

    public void effectAllPersonnageState(Board board) {
        for (Character c : board.getCharacters())
            if (this.states.containsKey(c)) {
                APersonnageState[] states = this.states.get(c);
                for (int i=0;i<states.length;i++)
                    if (states[i] != null)
                        if (states[i].effect(c)) {
                            states[i] = null;
                            c.getStats().removeCharacterState(i);
                        }
            }
    }

    private APersonnageState createPersonnageState(int i) {
        return switch (i) {
            case 0 -> new PoisionState(5);
            case 1 -> new BurnState(3);
            case 2 -> new SlowState(2);
            case 3 -> new BleedingState(4);
            case 4 -> new BlockState(1);
            case 5 -> new FreezingState(1);
            default -> throw new RuntimeException("probleme avec la creation d'un PersonnageState");
        };
    }

    @Override
    public void update(EEventType eventType, Object data) {
        if (eventType != EEventType.NEW_PERSONNAGE_STATE)
            return ;


        Object[] datas = (Object[]) data;
        int typePersonnageState = (int) datas[0];
        int duration = (int) datas[1];
        Character personnage = (Character) datas[2];

        if (!this.states.containsKey(personnage))
            this.states.put(personnage, new APersonnageState[10]);

        //TODO change par utlisation d'un log pour remplacer le switch
        switch (typePersonnageState) {
            case 1    -> this.states.get(personnage)[0] = new PoisionState(duration);
            case 1<<1 -> this.states.get(personnage)[1] = new BurnState(duration);
            case 1<<2 -> this.states.get(personnage)[2] = new SlowState(duration);
            case 1<<3 -> this.states.get(personnage)[3] = new BleedingState(duration);
            case 1<<4 -> this.states.get(personnage)[4] = new BlockState(duration);
            case 1<<5 -> this.states.get(personnage)[5] = new FreezingState(duration);
        };

    }
}
