package mmk.model.action;

import mmk.model.personnage.Character;
import mmk.model.util.eventmanagement.EEventType;
import mmk.model.util.eventmanagement.EventManager;
import mmk.model.world.Board;

public class Attack implements IAction {

    @Override
    public void doo(Character personnage, Board board, int... args) {
        EventManager.EVENT_MANAGER.notify(EEventType.ATTACK, personnage);
        personnage.attack(board);
    }
}
