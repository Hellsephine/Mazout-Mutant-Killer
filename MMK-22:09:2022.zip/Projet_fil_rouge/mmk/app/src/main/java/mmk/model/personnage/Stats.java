package mmk.model.personnage;

import mmk.model.personnage.state.EPersonnageState;
import mmk.model.util.Vector2;
import mmk.model.util.eventmanagement.EEventType;
import mmk.model.util.eventmanagement.EventManager;

import javax.persistence.*;
import java.util.Objects;
import java.util.Vector;

@Entity
@Table(name = "stats")
public class Stats {

    //#region attributes
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "pa")
    private Integer pa;

    @Column(name = "pm")
    private Integer pm;

    @Column(name = "hp")
    private Integer hp;

    @Column(name = "strength")
    private Integer strength;

    @Column(name = "max_hp")
    private Integer maxHp;

    @Column(name = "character_state")
    private Integer characterState;

    @Column(name = "direction")
    private String directionString;

    @Column(name = "blackgold")
    private Integer blackGold;

    @Column(name = "position")
    private String positionString;

    @Transient
    private Vector2 direction;
    @Transient
    private Vector2 position;
    @Transient
    private int currentPa;
    @Transient
    private int currentPm;
    //#endregion

    //#region constructor
    public Stats() { }

    public Stats(int pa, int pm, int maxHp, int strength, int characterState, String directionString, String positionString) {
        this.setPa(pa);
        this.setPm(pm);
        this.setMaxHp(maxHp);
        this.setHp(maxHp);
        this.setStrength(strength);
        this.setCharacterState(characterState);
        this.setDirectionString(directionString);
        this.setDirection(new Vector2(directionString));
        this.setPosition(new Vector2(positionString));
    }
    //#endregion

    //#region is/has
    public boolean hasPersonnageState(EPersonnageState personnageState) {
        return (this.getCharacterState()&personnageState.value)>0;
    }
    public boolean hasPersonnageState(int personnageState) {
        return (this.getCharacterState()&personnageState)>0;
    }
    //#endregion

    //#region adder/remover
    public void addHp(int amount) {
        this.setHp(Math.min(this.getMaxHp(), this.getHp()+amount));
    }

    public void removeHp(int amount) {
        this.setHp(this.getHp()-amount);
    }

    public void addPa(int amount) {
        this.setPa(this.getPa()+amount);
    }

    public void removePa(int amount) {
        this.setPa(this.getPa()-amount);
    }

    public void addPm(int amount) {
        this.setPm(this.getPm()+amount);
    }

    public void removePm(int amount) {
        this.setPm(this.getPm()-amount);
    }

    public void addStrength(int amount) {
        this.setStrength(this.getStrength()+amount);
    }

    public void removeStrength(int amount) {
        this.setStrength(this.getStrength()-amount);
    }

    public void addCharacterState(int characterState) {
        this.setCharacterState(this.getCharacterState() | characterState);
    }

    public void removeCharacterState(int characterState) {
        if (this.hasPersonnageState(characterState))
            this.setCharacterState(this.getCharacterState() ^ characterState);
    }

    public void addCharacterState(EPersonnageState characterState, int duration) {
        this.setCharacterState(this.getCharacterState() | characterState.value);
        EventManager.EVENT_MANAGER.notify(EEventType.NEW_PERSONNAGE_STATE, new Object[]{characterState.value, duration, this});
    }

    public void removeCharacterState(EPersonnageState characterState) {
        this.setCharacterState(this.getCharacterState() ^ characterState.value);
    }

    public void addCurrentPa(int amount) {
        this.setCurrentPa(this.getCurrentPa()+amount);
    }

    public void removeCurrentPa(int amount) {
        this.setCurrentPa(this.getCurrentPa()-amount);
    }

    public void addCurrentPm(int amount) {
        this.setCurrentPm(this.getCurrentPm()+amount);
    }

    public void removeCurrentPm(int amount) {
        this.setCurrentPm(this.getCurrentPm()-amount);
    }

    public void addBlackGold(int amount) {
        this.setBlackGold(this.getBlackGold()+amount);
    }

    public void removeBlackGold(int amount) {
        this.setBlackGold(this.getBlackGold()-amount);
    }

    public void removeAllCharacterState() {
        this.setCharacterState(0);
    }
    //#endregion

    //#region getters/setters

    public Integer getId() {
        return id;
    }

    public Integer getPa() {
        return pa;
    }

    public void setPa(Integer pa) {
        this.pa = pa;
    }

    public Integer getPm() {
        return pm;
    }

    public void setPm(Integer pm) {
        this.pm = pm;
    }

    public Integer getHp() {
        return hp;
    }

    public void setHp(Integer hp) {
        this.hp = hp;
    }

    public Integer getStrength() {
        return strength;
    }

    public void setStrength(Integer strength) {
        this.strength = strength;
    }

    public Integer getMaxHp() {
        return maxHp;
    }

    public void setMaxHp(int maxHp) {
        this.maxHp = maxHp;
    }

    public Integer getCharacterState() {
        return characterState;
    }

    public void setCharacterState(int characterState) {
        this.characterState = characterState;
    }

    public String getDirectionString() {
        return directionString;
    }

    public void setDirectionString(String directionString) {
        this.directionString = directionString;
    }

    public Vector2 getDirection() {
        return direction;
    }

    public void setDirection(Vector2 direction) {
        this.direction = direction;
    }

    public int getCurrentPa() {
        return currentPa;
    }

    public void setCurrentPa(int currentPa) {
        this.currentPa = currentPa;
    }

    public int getCurrentPm() {
        return currentPm;
    }

    public void setCurrentPm(int currentPm) {
        this.currentPm = currentPm;
    }

    public Vector2 getPosition() {
        return position;
    }

    public void setPosition(Vector2 position) {
        this.position = position;
    }

    public String getPositionString() {
        return positionString;
    }

    public void setPositionString(String positionString) {
        this.positionString = positionString;
    }

    public int getBlackGold() {
        return blackGold;
    }

    public void setBlackGold(int blackGold) {
        this.blackGold = blackGold;
    }

    //#endregion


    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Stats s))
            return false;

        if (!this.getId().equals(s.getId()))
            return false;
        if (!this.getPa().equals(s.getPa()))
            return false;
        if (!this.getPm().equals(s.getPm()))
            return false;
        if (!this.getHp().equals(s.getHp()))
            return false;
        if (!this.getMaxHp().equals(s.getMaxHp()))
            return false;
        if (!this.getStrength().equals(s.getStrength()))
            return false;
        if (!this.getCharacterState().equals(s.getCharacterState()))
            return false;
        if (!this.getDirectionString().equals(s.getDirectionString()))
            return false;
        if (!this.getPositionString().equals(s.getPositionString()))
            return false;
        if (!this.getDirection().equals(s.getDirection()))
            return false;
        if (!this.getPosition().equals(s.getPosition()))
            return false;
        if (this.getCurrentPa() != s.getCurrentPa())
            return false;
        if (this.getCurrentPm() != s.getCurrentPm())
            return false;

        return true;
    }

}
