package mmk.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import mmk.model.item.equipable.weapon.StaticWeapon;

@Repository
public interface StaticWeaponRepository extends CrudRepository<StaticWeapon,Integer>{
    
    public List<StaticWeapon>findByStaticItem_PriceGreaterThan(int price);

}