package mmk.model.item;

import javax.persistence.*;

/**
 * représente un item
 */
@Entity
@Table(name = "static_item")
@Inheritance(strategy = InheritanceType.JOINED)
public class StaticItem {

    //#region attributs
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "iconurl")
    private String iconURL;

    @Column(name = "description")
    private String description;
    //#endregion

    public String getName(){
        return name;
    }
    public String getIconURL(){
        return iconURL;
    }
    public int getId() {
        return id;
    }
    public String getDescription() {
        return description;
    }


    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof StaticItem s))
            return false;

        if (!this.name.equals(s.name))
            return false;
        if (!this.description.equals(s.description))
            return false;
        if (!this.iconURL.equals(s.iconURL))
            return false;

        return true;
    }
}
