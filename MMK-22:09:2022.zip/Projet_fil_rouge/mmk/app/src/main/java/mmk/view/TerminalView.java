package mmk.view;

import mmk.controllers.TerminalController;
import mmk.model.personnage.Character;
import mmk.model.util.eventmanagement.EEventType;
import mmk.model.util.eventmanagement.EventListener;

import java.util.Scanner;

public class TerminalView implements EventListener {

    private final Scanner scan = new Scanner(System.in);
    private final TerminalController controller;

    public TerminalView(TerminalController controller) {
        this.controller = controller;
    }


    public void getInput() {
        this.controller.action(this.scan.nextInt());
    }

    public void print(Character[][] personnages) {
        int i=1;
        for (int y=0;y<5;y++) {
            for (int x=0;x<10;x++) {
                if (personnages[y][x] != null)
                    System.out.print(personnages[y][x].getId() + " ");
                else
                    System.out.print(0 + " ");
            }
            System.out.println();
        }
        System.out.println();
        System.out.println();
    }

    @Override
    public void update(EEventType eventType, Object data) {
        if (EEventType.MODIFY_APERSONNAGE_BOARD.equals(eventType))
            this.print((Character[][]) data);
        if (EEventType.ASK_TERMINAL_INPUT.equals(eventType))
            this.getInput();
        if (EEventType.GET_HIT.equals(eventType))
            if (((Character)data).isDead())
                System.out.println(((Character)data).getName() + " a prit des dégât, et il en est mort");
            else
                System.out.println(((Character)data).getName() + " a prit des dégât, il lui reste " + ((Character)data).getHp() + " points de vie");
        if (EEventType.ATTACK.equals(eventType))
            System.out.println(((Character)data).getName() + " tente une attaque");
    }
}
