package mmk.services;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mmk.dao.StaticWeaponRepository;
import mmk.model.item.equipable.weapon.StaticWeapon;

@Service
public class HighlightWeaponServices {
    
    @Autowired
    private StaticWeaponRepository staticWeaponRepository;

    public  List<StaticWeapon> getStaticWeaponByRandomHighlight()
    {
        List<StaticWeapon> staticWeapon = staticWeaponRepository.findByStaticItem_PriceGreaterThan(0);
        Collections.shuffle(staticWeapon);

        int NbrHighlight = 3;

        List<StaticWeapon> HightlightWeapon = staticWeapon.subList(0, NbrHighlight);

        return HightlightWeapon;
    }
}
