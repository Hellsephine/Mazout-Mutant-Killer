package mmk.model.personnage.state;

import mmk.model.personnage.Character;

public class BlockState extends APersonnageState{

    public BlockState(int duration) {
        super(duration);
    }

    @Override
    public boolean effect(Character personnage) {
        return --this.duration == 0;
    }
}
