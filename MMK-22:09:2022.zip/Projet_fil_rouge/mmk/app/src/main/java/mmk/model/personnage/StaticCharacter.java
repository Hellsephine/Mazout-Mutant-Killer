package mmk.model.personnage;

import javax.persistence.*;

@Entity
@Table(name = "static_character")
public class StaticCharacter {

    //#region attributes
    @Id
    @Column(name = "id")
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "iconurl")
    private String iconurl;

    @Column(name = "pa")
    private Integer pa;

    @Column(name = "pm")
    private Integer pm;

    @Column(name = "max_hp")
    private Integer maxHp;

    @Column(name = "strength")
    private Integer strength;
    //#endregion

    //#region getters
    public String getName() {
        return name;
    }
    public String getDescription() {
        return description;
    }
    public String getIconurl() {
        return iconurl;
    }
    public Integer getPa() {
        return pa;
    }
    public Integer getPm() {
        return pm;
    }
    public Integer getMaxHp() {
        return maxHp;
    }
    public Integer getStrength() {
        return strength;
    }
    //#endregion
}
