package mmk.model.action;

import mmk.model.personnage.Character;
import mmk.model.world.Board;

public class Consume implements IAction{


    @Override
    public void doo(Character c, Board board, int... args) {
        //c.consume(args[0]); // TODO gestion des consommable
    }
}
