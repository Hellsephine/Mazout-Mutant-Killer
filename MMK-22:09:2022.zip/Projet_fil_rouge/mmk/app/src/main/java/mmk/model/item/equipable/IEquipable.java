package mmk.model.item.equipable;

import mmk.model.personnage.Character;

/**
 * représente les objets qu'un character peut equiper
 */
public interface IEquipable {

    /**
     * permet d'equiper l'objet sur un character
     * @param target le character à equiper
     */
    void equip(Character target);

    /**
     * permet de desequiper l'obget du character
     * @param target le character à desequiper
     */
    void unequip(Character target);

    int use(Character character, int degatTheorique);
}
