package mmk.model.world;


import javax.persistence.*;
import mmk.model.action.EActionState;
import mmk.model.personnage.Character;
import mmk.model.personnage.hero.Hero;
import mmk.model.personnage.monster.Monster;
import mmk.model.personnage.state.PersonnageStateManager;
import mmk.model.util.eventmanagement.EEventType;
import mmk.model.util.eventmanagement.EventManager;

import java.util.Set;

@Entity
@Table(name = "save")
public class Save {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "blackgold")
    private Integer blackgold;

    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "id")
    private Set<Board> boards;

    @Transient
    private Board[] stages;

    @Transient
    private Board currentStage;

    @PostLoad
    public void postLoad() {
        this.stages = new Board[this.boards.size()];

        for (Board board : this.boards)
            this.stages[board.getStage()] = board;

        this.currentStage = this.stages[0];


        EventManager.EVENT_MANAGER.notify(EEventType.MODIFY_ACHARACTER_BOARD, this.currentStage.getCharacters());
        EventManager.EVENT_MANAGER.notify(EEventType.MODIFY_BACKGROUND_BOARD, this.currentStage.getBackgroundBoard());
    }

    public void play() {

        PersonnageStateManager.PERSONNAGE_STATE_MANAGER.effectAllPersonnageState(this.currentStage);
        this.effectCard();

        for (Character hero : this.currentStage.getHeros()) {
            if (!hero.isDead()) {
                EActionState[] actionStates = hero.getActionState();
                for (int i = 0; i < actionStates.length; i++) {
                    actionStates[i].action.doo(hero, currentStage, actionStates[i].getArguments());
                    EventManager.EVENT_MANAGER.notify(EEventType.MODIFY_ACHARACTER_BOARD, this.currentStage.getCharacters());
                }
                hero.resetActionState();
                hero.getStats().setCurrentPa(hero.getStats().getPa());
                hero.getStats().setCurrentPm(hero.getStats().getPm());
            } else {
                throw new RuntimeException("Hero dead");
            }
        }
        // gestion appel a LootManager ici

        for (Character monster : this.currentStage.getMonsters()) {
            if (!monster.isDead()) {
                while (monster.getStats().getCurrentPa() > 0 || monster.getStats().getCurrentPm() > 0) {
                    if (monster.setActionState(this.currentStage)) { // TODO changer ça, pour taper l'ia du monster
                        monster.getStats().setCurrentPa(0);
                    } else {
                        EActionState[] actionStates = monster.getActionState();
                        actionStates[0].action.doo(monster, currentStage, actionStates[0].getArguments());
                        EventManager.EVENT_MANAGER.notify(EEventType.MODIFY_ACHARACTER_BOARD, this.currentStage.getCharacters());
                    }
                    monster.resetActionState();
                }
                monster.getStats().setCurrentPa(monster.getStats().getPa());
                monster.getStats().setCurrentPm(monster.getStats().getPm());
            } else {
//                monster.Die(); // TODO refaire la method die
                this.currentStage.removeCharacter(monster);
                EventManager.EVENT_MANAGER.notify(EEventType.MODIFY_ACHARACTER_BOARD, this.currentStage.getCharacters());
            }
        }
        // gestion du L'event Game Over 
    }

    public Character getHero() {
        return this.currentStage.getHeros()[0];
    }

    public int addPersonnageActionState(Character target, EActionState state) {
        return target.addActionState(state);
    }


    public void notifyNew() {
        EventManager.EVENT_MANAGER.notify(EEventType.MODIFY_ACHARACTER_BOARD, this.currentStage.getCharacters());
    }

    public void effectCard() {
        for (Character hero : this.currentStage.getHeros())
            if (!hero.isDead())
                hero.getDeck().effects(this.currentStage);
    }

}
