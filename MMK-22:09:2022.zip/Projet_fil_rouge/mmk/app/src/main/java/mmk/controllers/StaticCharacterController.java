package mmk.controllers;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import mmk.model.personnage.StaticCharacter;
import mmk.services.HighlightStaticCharacterServices;
import mmk.services.StaticCharacterServices;

@RestController
public class StaticCharacterController {
    
    @Autowired
    private StaticCharacterServices staticCharacterServices;

    @Autowired
    private HighlightStaticCharacterServices highlightStaticCharacterServices;

    @GetMapping("/api/staticherobytype")
    public List<StaticCharacter> getStaticCharacterByType()
	{
		List<StaticCharacter> staticCharacter = staticCharacterServices.getStaticCharacterByType();
		
		return staticCharacter;
	}

    @GetMapping("/api/staticherobyid")
    public StaticCharacter getStaticCharacterById(int id) 
	{
		try {
            return staticCharacterServices.getStaticCharacterById(id);
        } catch (Exception e) {
            throw new ResponseStatusException(
                HttpStatus.NOT_FOUND, "Entity not found"
              );
        }
	}

    @GetMapping("/api/highlighthero")
    public List<StaticCharacter> getHighlightStaticCharacter(){
        try{
            return highlightStaticCharacterServices.getStaticCharacterByRandomHighlight();
        } catch(Exception e) {
            throw new ResponseStatusException(
                HttpStatus.NOT_FOUND, "Entity not found"
              );
        }
    }

}
