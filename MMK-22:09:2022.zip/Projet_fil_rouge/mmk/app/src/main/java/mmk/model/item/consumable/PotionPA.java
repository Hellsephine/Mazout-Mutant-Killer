package mmk.model.item.consumable;

import mmk.model.personnage.Character;

/**
 * représente la Potion de point d'action, qui permet d'avoir plus de point d'action
 */
public class PotionPA extends AConsumable {

    protected PotionPA() {
        super(23);
    }


    @Override
    public void consume(Character c) {
        c.getStats().addPa(1);
    }
}


    