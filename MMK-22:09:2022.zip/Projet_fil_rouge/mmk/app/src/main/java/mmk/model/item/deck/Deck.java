package mmk.model.item.deck;

import mmk.model.item.Inventory;
import mmk.model.item.deck.card.ACard;
import mmk.model.util.Manager;
import mmk.model.world.Board;

import java.util.*;

/**
 * représente un deck de carte
 */
public class Deck {

    private final HashMap<ACard, Integer> deck = new HashMap<>();

    public Deck(Set<Inventory> inventoryList) {
        for (Inventory inventory : inventoryList)
            if (inventory.getType().equals("card"))
                this.deck.put(Manager.createCard(inventory.getIdItem()), inventory.getAmount());
    }

    /**
     * call effect methods on all cards
     * @param board the board
     */
    public void effects(Board board) {
        for (ACard c : this.getCards())
            c.effect(board, board.getNbTour());
    }

    /**
     *
     * @return an array with all the cards
     */
    public ACard[] getCards() {
        ArrayList<ACard> cards = new ArrayList<>();
        for (ACard card : this.deck.keySet())
            for (int i=0;i<this.deck.get(card);i++)
                cards.add(card);
        return cards.toArray(ACard[]::new);
    }

    /**
     * add a card to the deck
     * @param card the card to add
     */
    public void addCard(ACard card) {
        if (this.deck.containsKey(card))
            this.deck.put(card, this.deck.get(card)+1);
        else
            this.deck.put(card, 1);
    }
    
}
