package mmk.model.personnage.state;

import mmk.model.personnage.Character;

public abstract class APersonnageState {

    protected int duration;

    public APersonnageState(int duration) {
        this.duration = duration;
    }

    public abstract boolean effect(Character c);
}
