package mmk.services;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mmk.dao.StaticCharacterRepository;
import mmk.model.personnage.StaticCharacter;

@Service
public class HighlightStaticCharacterServices {
    
    @Autowired
    private StaticCharacterRepository staticCharacterRepository;

    public List<StaticCharacter> getStaticCharacterByRandomHighlight()
    {
        List<StaticCharacter> staticCharacter = staticCharacterRepository.findByType(0);
        Collections.shuffle(staticCharacter);

        int NbrHighlight = 3;

        List<StaticCharacter> HightlightStaticCharacter = staticCharacter.subList(0, NbrHighlight);

        return HightlightStaticCharacter;
    }
}
