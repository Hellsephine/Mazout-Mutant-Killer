package mmk.model.util;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;

import java.sql.*;

public class DBConnection {

    public static final Session SESSION = new Configuration().configure().buildSessionFactory().openSession();

}
