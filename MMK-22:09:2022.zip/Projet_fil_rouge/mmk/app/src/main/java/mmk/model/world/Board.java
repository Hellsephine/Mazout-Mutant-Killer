package mmk.model.world;


import javax.persistence.*;
import mmk.model.personnage.Character;
import mmk.model.util.Vector2;

import java.util.HashSet;
import java.util.Set;

/**
 * classe représentant le plateau de jeu
 */
@Entity
@Table(name = "board")
public class Board {

    //#region attribut
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "nb_tour")
    private Integer nbTour;

    @Column(name = "width")
    private Integer width;

    @Column(name = "height")
    private Integer height;

    @Column(name = "background_board")
    private String backgroundBoard;

    @Column(name = "power_level")
    private Integer powerLevel;

    @Column(name = "id_save")
    private Integer idSave;

    @Column(name = "stage")
    private Integer stage;

    @OneToMany
    @JoinColumn(name = "id_board")
    private Set<Character> characters;
    //#endregion

    //#region constructor
    public Board() {}

    public Board(int width, int height, int idSave, int powerLevel, int stage) {
        this.width = width;
        this.height = height;
        this.characters = new HashSet<>();
        this.idSave = idSave;
        this.nbTour = 0;
        this.powerLevel = powerLevel;
        this.stage = stage;
    }
    //#endregion

    //#region move
    /**
     * permet de bouger un personnage d'une case à l'autre
     * @param from la position de départ
     * @param to la position d'arrivée
     */
    public void move(Vector2 from, Vector2 to) {
        boolean free = true;
        Character characterToMove = null;
        for (Character c : this.getCharacters())
            if (c.getStats().getPosition().equals(from))
                characterToMove = c;
            else if (c.getStats().getPosition().equals(to))
                free = false;

        if (characterToMove != null)
            characterToMove.getStats().setPosition(to);
    }

    /**
     * permet de bouger un personnage d'une case dans la direction
     * @param character le personnage
     * @param direction la direction (-1=gauche, 1=droite)
     */
    public void move(Character character, int direction) {
        if (character.getStats().getDirection().equals(new Vector2(direction)))
            this.move(character.getStats().getPosition(), character.getStats().getPosition().add(new Vector2(direction)));
        else
            character.getStats().setDirection(new Vector2(direction));
    }

    /**
     * permet de déplacer le personnage d'une case dans sa direction
     * @param character le personnage
     */
    public void move(Character character) {
        this.move(character.getStats().getPosition(), character.getStats().getPosition().add(character.getStats().getDirection()));
    }
    //#endregion

    //#region adder/remover
    /**
     * permet d'ajouter un personnage sur le plateau
     * @param character le personnage à ajouter
     * @param position la position du personnage
     */
    public void addCharacter(Character character, Vector2 position){
        for (Character value : this.getCharacters())
            if (value.getStats().getPosition().equals(position))
                return;

        character.getStats().setPosition(position);
    }

    public void removeCharacter(Character character) {
        this.characters.remove(character);
    }
    //#endregion

    //#region getter/setter

    /**
     * renvoie le character le plus proche dans la zone d'attaque de son arme, null si personne
     * @param character le character
     * @return le character le plus proche dans la zone d'attaque de son arme, null si personne
     */
    public Character getInRange(Character character) {
        Character res = null;
        for (Character c : this.getCharacters()) {
            int minRange = character.getWeapon().getMinRange();
            int maxRange = character.getWeapon().getMaxRange();
            int direction = character.getStats().getDirection().getX();
            int position = character.getStats().getPosition().getX();

            if (position + (minRange*direction) < c.getStats().getPosition().getX()
            && position + (maxRange*direction) > c.getStats().getPosition().getX())
                if (res == null)
                    res = c;
                else
                    if (position + c.getStats().getPosition().getX() < position + res.getStats().getPosition().getX())
                        res = c;
        }
        return res;
    }

    /**
     * retour le personnage à la position pos, null si personne
     * @param pos la position
     * @return un personnage ou null
     */
    public Character getAtPosition(Vector2 pos) {
        for (Character c : this.getCharacters())
            if (c.getStats().getPosition().equals(pos))
                return c;
        return null;
    }

    public Integer getNbTour() {
        return nbTour;
    }

    public void setNbTour(Integer nbTour) {
        this.nbTour = nbTour;
    }

    public Integer getWidth() {
        return width;
    }

    public void setWidth(Integer width) {
        this.width = width;
    }

    public Integer getHeight() {
        return height;
    }

    public void setHeight(Integer height) {
        this.height = height;
    }

    public Integer getPowerLevel() {
        return powerLevel;
    }

    public void setPowerLevel(Integer powerLevel) {
        this.powerLevel = powerLevel;
    }

    public Integer getIdSave() {
        return idSave;
    }

    public void setIdSave(Integer idSave) {
        this.idSave = idSave;
    }

    public Integer getStage() {
        return stage;
    }

    public void setStage(Integer stage) {
        this.stage = stage;
    }

    public Set<Character> getCharacters() {
        return characters;
    }

    public void setCharacters(Set<Character> characters) {
        this.characters = characters;
    }

    public Character[] getCharacterByType(int type) {
        Set<Character> res = new HashSet<>();
        for (Character c : this.getCharacters())
            if (c.getType() == type)
                res.add(c);
        return res.toArray(Character[]::new);
    }

    public Character[] getHeros() {
        return this.getCharacterByType(1);
    }

    public Character[] getMonsters() {
        return this.getCharacterByType(2);
    }

    public String getBackgroundBoard() {
        return backgroundBoard;
    }

    public void setBackgroundBoard(String backgroundBoard) {
        this.backgroundBoard = backgroundBoard;
    }

    //#endregion
}
