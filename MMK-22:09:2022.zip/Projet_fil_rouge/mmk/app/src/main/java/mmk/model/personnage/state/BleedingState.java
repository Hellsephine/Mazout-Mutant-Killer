package mmk.model.personnage.state;

import mmk.model.personnage.Character;

public class BleedingState extends APersonnageState{

    public BleedingState(int duration) {
        super(duration);
    }

    @Override
    public boolean effect(Character personnage) {
        personnage.getStats().removeHp(1);

        return --this.duration == 0;
    }
}
