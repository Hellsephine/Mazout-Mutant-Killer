package mmk.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mmk.dao.StaticArmorRepository;
import mmk.exceptions.StaticArmorNotFoundException;
import mmk.model.item.equipable.armor.StaticArmor;

@Service
public class StaticArmorServices {
    
    @Autowired
    private StaticArmorRepository staticArmorRepository;

    public StaticArmor getStaticArmorById(int id) throws StaticArmorNotFoundException
    {
        Optional<StaticArmor> staticArmor = staticArmorRepository.findById(id);
        if(staticArmor.isPresent()){
            StaticArmor staticArmor2 = staticArmor.get();
            return staticArmor2;
        }
        else{
            throw new StaticArmorNotFoundException();
        }
   }

   public List<StaticArmor> getStaticArmorByStaticItem_PriceGreaterThan(int price) throws StaticArmorNotFoundException
    {
        List<StaticArmor> staticArmor = staticArmorRepository.findByStaticItem_PriceGreaterThan(price);
        if(staticArmor != null){
            return staticArmor;
        }
        else{
            throw new StaticArmorNotFoundException();
        }
    }
}

