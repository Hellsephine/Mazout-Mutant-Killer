package mmk.model.item.deck.card;

import mmk.model.item.StaticItem;
import mmk.model.util.DBConnection;
import mmk.model.world.Board;


public abstract class ACard {

    public static final RegenHpCard REGEN_HP_CARD = new RegenHpCard();
    public static final PaPairImpairCard PA_PAIR_IMPAIR_CARD = new PaPairImpairCard();
    public static final StrengthT2Card STRENGTH_T2_CARD = new StrengthT2Card();
    public static final StrengthPairCard STRENGTH_PAIR_CARD = new StrengthPairCard();
    public static final StrengthCard STRENGTH_CARD = new StrengthCard();
    public static final StrengthForHealingCard STRENGTH_FOR_HEALING_CARD = new StrengthForHealingCard();
    public static final StrengthIfHurtCard STRENGTH_IF_HURT_CARD = new StrengthIfHurtCard();
    public static final StrengthBonusAttackCard STRENGTH_BONUS_ATTACK_CARD = new StrengthBonusAttackCard();

    private final StaticItem staticItem;

    public ACard(int id) {
        this.staticItem = DBConnection.SESSION.getReference(StaticItem.class, id);
    }

    public abstract void effect(Board board, int nbTours);

    public StaticItem getStaticItem() {
        return this.staticItem;
    }
}
