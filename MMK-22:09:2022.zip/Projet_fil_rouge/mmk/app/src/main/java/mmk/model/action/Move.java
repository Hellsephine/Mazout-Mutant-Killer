package mmk.model.action;

import mmk.model.personnage.Character;
import mmk.model.world.Board;

public class Move implements IAction {

    @Override
    public void doo(Character personnage, Board board, int... args) {
        board.move(personnage, args[0]);
    }
}
