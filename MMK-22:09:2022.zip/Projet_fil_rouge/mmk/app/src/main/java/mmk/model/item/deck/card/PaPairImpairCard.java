package mmk.model.item.deck.card;

import mmk.model.personnage.Character;
import mmk.model.world.Board;

public class PaPairImpairCard extends ACard {

    public PaPairImpairCard() {
        super(2);
    }

    public void effect(Board board, int nbTours) {
        int paBonus = 1;
        if (nbTours % 2 == 0) {
            for (Character hero : board.getHeros())
                hero.getStats().addPa(paBonus);

            if(nbTours != 0)
                for(Character monster: board.getMonsters())
                    monster.getStats().removePa(paBonus);

        }
        else{
            for (Character monster : board.getMonsters())
                monster.getStats().addPa(paBonus);

            for(Character hero: board.getHeros())
                hero.getStats().removePa(paBonus);

        }
    }
}
