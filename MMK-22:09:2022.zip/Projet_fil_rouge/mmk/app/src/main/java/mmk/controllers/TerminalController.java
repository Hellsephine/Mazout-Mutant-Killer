package mmk.controllers;

import mmk.model.action.EActionState;
import mmk.model.item.consumable.AConsumable;
import mmk.model.personnage.hero.Hero;
import mmk.model.util.eventmanagement.EEventType;
import mmk.model.util.eventmanagement.EventManager;
import mmk.model.world.Save;

import java.util.HashMap;

public class TerminalController {

    private final Save modelAction;
    private final Hero hero;
    private State state;

    public TerminalController(Save modelAction) {
        this.modelAction = modelAction;
        this.hero = this.modelAction.getHero();
        this.state = State.NONE;
    }

    public void action(int in) {

        int paLeft = modelAction.getHero().getCurrentPa();
        int pmLeft = modelAction.getHero().getCurrentPm();
        if (State.NONE.equals(this.state)) {
            switch (in) {
                case 1:
                    this.state = State.MOVE;
                    System.out.println("-1: gauche, 1: droite");
                    break;
                case 2:
                    paLeft = modelAction.addPersonnageActionState(this.hero, EActionState.ATTACK);
                    break;
                case 3:
                    this.state = State.CONSUME;

                    HashMap<AConsumable, Integer> map = this.hero.getConsumables();
                    StringBuilder builder = new StringBuilder();
                    for (AConsumable consumable : map.keySet()) {
                        builder.append(consumable.getId()).append(" : ").append(consumable.getName()).append(" (").append(map.get(consumable)).append("), ");
                    }

                    System.out.println(builder.substring(0, builder.length()-2));
                    break;
                case 4:
                    paLeft = modelAction.addPersonnageActionState(this.hero, EActionState.BLOCK);
                    break;
                case 5 :
                    pmLeft = modelAction.addPersonnageActionState(this.hero, EActionState.JUMP);
            }
        } else if (State.MOVE.equals(this.state)) {
            pmLeft = modelAction.addPersonnageActionState(this.hero, EActionState.MOVE.setArguments(in));
            this.state = State.NONE;
        }
        else if (State.CONSUME.equals(this.state)) {
            paLeft = modelAction.addPersonnageActionState(this.hero, EActionState.CONSUME.setArguments(in));
            this.state = State.NONE;
        }


        if ((paLeft <= 0 && pmLeft <= 0) || (State.NONE.equals(this.state) && in==-11))
            this.modelAction.play();

        if (State.NONE.equals(this.state)) {
            System.out.println("pa : " +modelAction.getHero().getCurrentPa() + ", pm : " + modelAction.getHero().getCurrentPm());
            System.out.println("1 : move, 2 : attaquer, 3 : consomer, 4 : block, 5 : jump, -11 : fin tour");
        }
        EventManager.EVENT_MANAGER.notify(EEventType.ASK_TERMINAL_INPUT, null);
    }


    private enum State {
        NONE,
        MOVE,
        CONSUME
    }

}
