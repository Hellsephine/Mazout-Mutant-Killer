package mmk.model.item.equipable.weapon;

import javax.persistence.*;
import mmk.model.item.StaticItem;

@Entity
@Table(name = "static_weapon")
public class StaticWeapon {

    //#region attributes
    @Id
    @Column(name = "id")
    private Integer id;

    @Column(name = "damage")
    private Integer damage;

    @Column(name = "min_range")
    private Integer minRange;

    @Column(name = "max_range")
    private Integer maxRange;

    @ManyToOne
    @JoinColumn(name = "id_item")
    private StaticItem staticItem;
    //#endregion


    //#region getters
    public Integer getDamage() {
        return damage;
    }
    public Integer getMinRange() {
        return minRange;
    }
    public Integer getMaxRange() {
        return maxRange;
    }
    public StaticItem getStaticItem() {
        return staticItem;
    }
    //#endregion
}
