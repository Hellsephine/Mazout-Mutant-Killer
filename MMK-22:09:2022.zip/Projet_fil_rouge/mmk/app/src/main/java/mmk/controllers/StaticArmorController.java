package mmk.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import mmk.model.item.equipable.armor.StaticArmor;
import mmk.services.HighlightArmorServices;
import mmk.services.StaticArmorServices;

@RestController
public class StaticArmorController {
    
    @Autowired
    private StaticArmorServices staticArmorServices;

    @Autowired
    private HighlightArmorServices highlightArmorServices;

    @GetMapping("/api/staticarmorbyid")
    public StaticArmor getStaticArmorById(int id){
        try {
            return staticArmorServices.getStaticArmorById(id);
        } catch (Exception e) {
            throw new ResponseStatusException(
                HttpStatus.NOT_FOUND, "Entity not found"
              );
        }
    }

    @GetMapping("/api/staticarmorbyprice")
    public List<StaticArmor> getStaticArmorByStaticItem_PriceGreaterThan(int price){
        try {
            return staticArmorServices.getStaticArmorByStaticItem_PriceGreaterThan(price);
        } catch (Exception e) {
            throw new ResponseStatusException(
                HttpStatus.NOT_FOUND, "Entity not found"
              );
        }
    }

    @GetMapping("/api/highlightarmor")
    public List<StaticArmor> getHighlightArmor(){
        try{
            return highlightArmorServices.getStaticArmorByRandomHighlight();
        } catch(Exception e) {
            throw new ResponseStatusException(
                HttpStatus.NOT_FOUND, "Entity not found"
              );
        }
    }
}