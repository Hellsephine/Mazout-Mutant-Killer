package mmk.model.action;

import java.util.LinkedList;
import java.util.Queue;

public enum EActionState {
    ATTACK(new Attack(), true, 1),
    BLOCK(new Block(), true, 1),
    MOVE(new Move(), false, 1),
    CONSUME(new Consume(), true, 1),
    JUMP(new Jump(), false, 2);

    public final IAction action;
    public final boolean pa;
    public final int amount;
    private final Queue<Integer> arguments;

    EActionState(IAction action, boolean pa, int amount) {
        this.action = action;
        this.pa = pa;
        this.amount = amount;
        this.arguments = new LinkedList<>();
    }

    public EActionState setArguments(int args) {
        this.arguments.add(args);
        return this;
    }

    public boolean isPa() {
        return this.pa;
    }

    public int getAmount() {
        return this.amount;
    }

    public int getArguments() {
        if (this.arguments.size() > 0)
            return this.arguments.poll();
        else
            return 0;
    }
}
