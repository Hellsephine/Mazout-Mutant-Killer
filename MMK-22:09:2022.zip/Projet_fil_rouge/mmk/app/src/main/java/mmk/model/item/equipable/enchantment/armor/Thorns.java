package mmk.model.item.equipable.enchantment.armor;

import mmk.model.item.equipable.enchantment.IEnchantment;
import mmk.model.personnage.Character;

/**
 * représente l'enchantement Thorns, renvoie une partie des degats subi
 */
public class Thorns extends AEnchantmentArmor {

    public static final int idEnchantment = 101;

    /**
     * constructeur de Thorns
     * @param armor l'armure à enchanter
     */
    public Thorns(IEnchantment armor) {
        super(armor);
    }

    @Override
    public int use(Character character, int degattheorique) {
        if(degattheorique != 0){
            character.removeHp((int) (degattheorique*(10/100.0f)));
        }
        return super.use(character, degattheorique);
    }


    @Override
    public String getName() {
        return super.getName() + " avec l'enchantement Thorns";
    }
    @Override
    public String getDescription() {
        return super.getDescription() + " avec l'enchantment Thorns";
    }
    @Override
    public String getIconURL() {
        return super.getIconURL();
    }
    @Override
    public int getDefence() {
        return super.getDefence();
    }

}
