package mmk.model.util;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import mmk.model.personnage.Character;
import mmk.model.util.eventmanagement.EEventType;
import mmk.model.util.eventmanagement.EventManager;
import mmk.model.world.Board;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Random;



public class LootManager {
    
    private static final LinkedList<Character> piles= new LinkedList<Character>();
    private static final Random rand = new Random();

    public LootManager(){
    }
    public static void initJsonObject(Board board){
       try{

           FileReader reader = new FileReader(LootManager.class.getClassLoader().getResource("LootTable.json").getFile());
            JSONParser parser = new JSONParser();
            Object jsonObj = parser.parse(reader);

            JSONArray output = (JSONArray) jsonObj;

            while(!piles.isEmpty()){
                Character cur = (Character) piles.pop();
                for(int i =0; i<output.size();i++){
                    JSONObject curMonster = (JSONObject) output.get(i);

                    if(curMonster != null &&  cur.getType() == Math.toIntExact((long)curMonster.get("id"))){
                        initLootAndReturns(output.get(i), board);
                    }
                }
            }

       }catch (FileNotFoundException e) {
        e.printStackTrace();
        } catch (IOException e) {
        e.printStackTrace();
        } catch (Exception e) {
        e.printStackTrace();
        }

        
    }

    public static boolean isQueueOfDeadEmpty(){
        return piles.isEmpty();
    }

    //modifier pour prend le hero + le mob de la pile de cadavre

    public static void initLootAndReturns(Object o, Board board){
        // traitement pour les loots du mobs 
        try {
            JSONObject monstreData =(JSONObject) o;
            JSONObject data = (JSONObject) monstreData.get("data");
            JSONObject datagold = (JSONObject) data.get("gold");
            if(datagold != null){
                long chance = (long) datagold.get("chance");
                if(rand.nextInt(100)<= chance){
                   board.getHeros()[0].getStats().addBlackGold((int) datagold.get("amount"));
                }
            }
            JSONObject dataWeapon = (JSONObject) data.get("weapon");
            if(dataWeapon != null){
                long chance = (long) dataWeapon.get("chance");
                if(rand.nextInt(100)<= chance){
                    Object[] tab = {(long)dataWeapon.get("id"), board.getHeros()[0]};
                    EventManager.EVENT_MANAGER.notify(EEventType.LOOT_WEAPON, tab);
                }
            }
            JSONObject dataArmor = (JSONObject) data.get("armor");
            if(dataArmor != null){
                long chance = (long) dataArmor.get("chance");
                if(rand.nextInt(100)<= chance){
                    Object[] tab = {(long)dataWeapon.get("id"), board.getHeros()[0]};
                    EventManager.EVENT_MANAGER.notify(EEventType.LOOT_ARMOR, tab); 
                }
            }
            JSONObject dataCard = (JSONObject) data.get("card");
            if(dataCard != null){
                long chance = (long) dataCard.get("chance");
                if(rand.nextInt(100)<= chance){
                    EventManager.EVENT_MANAGER.notify(EEventType.LOOT_CARD, chance);     
                }
            }
            JSONObject dataConsumable = (JSONObject) data.get("consumable");
            if(dataConsumable != null){
                long chance = (long) dataConsumable.get("chance");
                if(rand.nextInt(100)<=chance){
                    Object[] tab ={Math.toIntExact((long) dataConsumable.get("id")) };
                    EventManager.EVENT_MANAGER.notify(EEventType.LOOT_CONSUMABLE, tab); 
                }
            }

        }catch(Exception e){
            new Exception("La gestion data a rencontre un probleme ");
        }
  

    }

    public static void cadavre(Character cur){
        piles.add(cur);
    }

}
