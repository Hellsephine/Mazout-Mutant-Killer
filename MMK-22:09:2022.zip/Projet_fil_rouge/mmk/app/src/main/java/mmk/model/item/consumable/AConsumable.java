package mmk.model.item.consumable;

import mmk.model.item.StaticItem;
import mmk.model.personnage.Character;
import mmk.model.util.DBConnection;

/**
 * représente des objets consomable
 */
public abstract class AConsumable {

    public static final PotionPA POTION_PA = new PotionPA();
    public static final PotionCleanse POTION_CLEANSE = new PotionCleanse();
    public static final PotionVie POTION_VIE = new PotionVie();

    private final StaticItem staticItem;

    public AConsumable(int id) {
        staticItem = DBConnection.SESSION.find(StaticItem.class, id); // TODO changer ça;
    }

    public abstract void consume(Character c);

    public StaticItem getStaticItem() {
        return this.staticItem;
    }
}
