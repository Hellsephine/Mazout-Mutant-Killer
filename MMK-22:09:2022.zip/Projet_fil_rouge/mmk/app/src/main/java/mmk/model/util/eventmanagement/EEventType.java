package mmk.model.util.eventmanagement;

/**
 * représente les types d'event
 */
public enum EEventType {
    MODIFY_ACHARACTER_BOARD,
    MODIFY_BACKGROUND_BOARD,
    ASK_TERMINAL_INPUT,
    ATTACK,
    GET_HIT,
    NEW_CHARACTER_STATE,
    LOOT_WEAPON,
    LOOT_ARMOR,
    LOOT_CARD,
    LOOT_CONSUMABLE
}
