package mmk.model.item.equipable.enchantment.armor;

import mmk.model.item.equipable.enchantment.IEnchantment;
import mmk.model.personnage.Character;

/**
 * représente l'enchantement Protection , qui réduit les dégat de 5 points
 */
public class ProtectionV extends AEnchantmentArmor {

    /**
     * constructeur de ProtectionV
     * @param armor l'armure à enchanter
     */
    public ProtectionV(IEnchantment armor) {
        super(armor);
    }

    @Override
    public int use(Character character, int degattheorique) {
        return super.use(character, degattheorique);
    }

    @Override
    public String getName() {
        return super.getName() + " avec l'enchantement ProtectionV";
    }
    @Override
    public String getDescription() {
        return super.getDescription() + " avec l'enchantment ProtectionV";
    }
    @Override
    public String getIconURL() {
        return super.getIconURL();
    }
    @Override
    public int getDefence() {
        return super.getDefence() + 5;
    }
}