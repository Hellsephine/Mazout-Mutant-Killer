package mmk.model.item.equipable.enchantment.weapon;

import mmk.model.item.equipable.weapon.Weapon;
import mmk.model.personnage.Character;

/**
 * représente l'enchangement Life steal, qui permet de récupérer des Pv selon un pourcentage de dégats infligé
 */
public class Lifesteal extends AEnchantmentWeapon {

    /**
     * constructeur de LifeSteal
     * @param weapon l'arme à enchanter
     */
    public Lifesteal(Weapon weapon) {
        super(weapon);
    }

    @Override
    public int use(Character character, int degattheorique) {
        if(degattheorique > 1){
            character.addHp((int) (degattheorique*(10/100.0f)));
        }
        return super.use(character, degattheorique);
        
    }

    @Override
    public String getName() {
        return super.getName() + " avec l'enchantement Lifesteal";
    }
    @Override
    public String getDescription() {
        return super.getDescription() + " avec l'enchantment Lifesteal";
    }
    @Override
    public String getIconURL() {
        return super.getIconURL();
    }
    @Override
    public int getMinRange() {
        return super.getMinRange();
    }
    @Override
    public int getMaxRange() {
        return super.getMaxRange();
    }
    @Override
    public int getDamage() {
        return super.getDamage();
    }
}
