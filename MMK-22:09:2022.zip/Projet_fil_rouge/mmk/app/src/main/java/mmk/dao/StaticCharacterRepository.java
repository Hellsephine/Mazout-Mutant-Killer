package mmk.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import mmk.model.personnage.StaticCharacter;

@Repository
public interface StaticCharacterRepository extends CrudRepository<StaticCharacter, Integer> {
    
    public List<StaticCharacter> findByType(int type);

}
