package mmk.exceptions;

public class StaticCharacterNotFoundException extends Exception {
    
}
