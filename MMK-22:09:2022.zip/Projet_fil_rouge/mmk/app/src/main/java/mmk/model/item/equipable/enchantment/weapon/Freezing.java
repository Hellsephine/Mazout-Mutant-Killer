package mmk.model.item.equipable.enchantment.weapon;

import mmk.model.item.equipable.enchantment.IEnchantment;
import mmk.model.personnage.Character;
import mmk.model.personnage.state.EPersonnageState;


/**
 * représente l'enchangement Freezing, qui ralenti la personne touché (-1Pa)
 */
public class Freezing extends AEnchantmentWeapon {

    private static final int idEnchantment = 2;

    /**
     * constructeur de Freezing
     * @param weapon l'arme à enchanter
     */
    public Freezing(IEnchantment weapon) {
        super(weapon);
    }

    @Override
    public int use(Character character, int degattheorique) {
        if(character.ischaracterState(EPersonnageState.FREEZING))
            return super.use(character, degattheorique);

        character.removePa(1);
        character.addcharacterState(EPersonnageState.FREEZING, 1);
        return super.use(character, degattheorique);
        
    }

    @Override
    public String getName() {
        return super.getName() + " avec l'enchantement Freezing";
    }
    @Override
    public String getDescription() {
        return super.getDescription() + " avec l'enchantment Freezing";
    }
    @Override
    public String getIconURL() {
        return super.getIconURL();
    }
    @Override
    public int getMinRange() {
        return super.getMinRange();
    }
    @Override
    public int getMaxRange() {
        return super.getMaxRange();
    }
    @Override
    public int getDamage() {
        return super.getDamage();
    }
}
