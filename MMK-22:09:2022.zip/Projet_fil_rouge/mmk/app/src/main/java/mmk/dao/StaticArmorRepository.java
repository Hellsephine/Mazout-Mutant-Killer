package mmk.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import mmk.model.item.equipable.armor.StaticArmor;

@Repository
public interface StaticArmorRepository extends CrudRepository<StaticArmor,Integer>{
    
    public List<StaticArmor> findByStaticItem_PriceGreaterThan(int price);

}