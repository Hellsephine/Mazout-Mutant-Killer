package mmk.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import mmk.model.item.equipable.weapon.StaticWeapon;
import mmk.services.HighlightWeaponServices;
import mmk.services.StaticWeaponServices;

@RestController
public class StaticWeaponController {
    
    @Autowired
    private StaticWeaponServices staticWeaponServices;

    @Autowired
    private HighlightWeaponServices highlightWeaponServices;

    @GetMapping("/api/staticweaponbyid")
    public StaticWeapon getStaticWeaponById(int id){
        try {
            return staticWeaponServices.getStaticWeaponById(id);
        } catch (Exception e) {
            throw new ResponseStatusException(
                HttpStatus.NOT_FOUND, "Entity not found"
              );
        }
    }

    @GetMapping("/api/staticweaponbyprice")
    public List<StaticWeapon> getStaticArmorByStaticItem_PriceGreaterThan(int price){
        try {
            return staticWeaponServices.getStaticWeaponByStaticItem_PriceGreaterThan(price);
        } catch (Exception e) {
            throw new ResponseStatusException(
                HttpStatus.NOT_FOUND, "Entity not found"
              );
        }    
    }

    @GetMapping("/api/highlightweapon")
    public List<StaticWeapon> getHighlightWeapon(){
        try{
            return highlightWeaponServices.getStaticWeaponByRandomHighlight();
        } catch(Exception e) {
            throw new ResponseStatusException(
                HttpStatus.NOT_FOUND, "Entity not found"
              );
        }
    }
}