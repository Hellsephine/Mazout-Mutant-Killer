package mmk.model.item.deck.card;

import mmk.model.personnage.Character;
import mmk.model.world.Board;

/**
 * Carte qui ajoute de la force si l'on a moins de 50% de ses Pv Max
 */
public class StrengthIfHurtCard extends ACard {

    public StrengthIfHurtCard() {
        super(7);
    }


    public void effect(Board board, int nbTours) {
        for (Character hero : board.getHeros())
            if(hero.getStats().getHp() < (hero.getStats().getMaxHp()/2))
                hero.getStats().addStrength(5);
    }

}
