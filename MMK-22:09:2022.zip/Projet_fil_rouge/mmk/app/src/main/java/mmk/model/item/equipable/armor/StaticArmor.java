package mmk.model.item.equipable.armor;

import javax.persistence.*;
import mmk.model.item.StaticItem;

@Entity
@Table(name = "static_armor")
public class StaticArmor {

    //#region attributes
    @Id
    @Column(name = "id")
    private Integer id;

    @Column(name = "defence")
    private Integer defence;

    @ManyToOne
    @JoinColumn(name = "id_item")
    private StaticItem staticItem;
    //#endregion

    //#region getters
    public Integer getId() {
        return this.id;
    }
    public Integer getDefence() {
        return defence;
    }
    public StaticItem getStaticItem() {
        return staticItem;
    }
    //#endregion

}
