package mmk.model.personnage.state;

import mmk.model.personnage.Character;

public class FreezingState extends APersonnageState{

    private boolean executed = false;
    private int previousPa;

    public FreezingState(int duration) {
        super(duration);
    }

    @Override
    public boolean effect(Character c) {
        if (!executed) {
            this.previousPa = c.getStats().getPa();
            c.getStats().removePa(this.previousPa);
            this.executed = true;
        }
        if (--this.duration == 0) {
            c.getStats().addPa(this.previousPa);
            return true;
        }
        return false;
    }
}
