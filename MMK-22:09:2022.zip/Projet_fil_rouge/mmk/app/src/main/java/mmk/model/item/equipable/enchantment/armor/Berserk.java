package mmk.model.item.equipable.enchantment.armor;

import mmk.model.item.equipable.enchantment.IEnchantment;
import mmk.model.personnage.Character;

/**
 * représente l'enchantement Berserk, qui fait gagner de la force si l'on prend un coup supérieur à la moitier de notre vie
 */

public class Berserk extends AEnchantmentArmor {

    /**
     * constructeur de Berserk
     * @param armor l'armure à enchanter
     */
    public Berserk(IEnchantment armor) {
        super(armor);
    }

    @Override
    public int use(Character character, int degattheorique) {
        if(degattheorique >= character.getMaxHp()*(50/100.0f))
            character.addStrength(1);

        return super.use(character, degattheorique);
    }

    @Override
    public String getName() {
        return super.getName() + " avec l'enchantement Berserk";
    }
    @Override
    public String getDescription() {
        return super.getDescription() + " avec l'enchantment Berserk";
    }
    @Override
    public String getIconURL() {
        return super.getIconURL();
    }
    @Override
    public int getDefence() {
        return super.getDefence();
    }
    
}
