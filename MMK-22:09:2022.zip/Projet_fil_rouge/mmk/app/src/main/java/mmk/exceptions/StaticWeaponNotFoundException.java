package mmk.exceptions;

public class StaticWeaponNotFoundException extends Exception {
    
}
