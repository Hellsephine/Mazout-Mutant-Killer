package mmk.model.personnage.state;

import mmk.model.personnage.Character;

public class SlowState extends APersonnageState{

    private boolean executed = false;

    public SlowState(int duration) {
        super(duration);
    }

    @Override
    public boolean effect(Character c) {
        if (!this.executed) {
            c.getStats().removePa(1);
            this.executed = true;
        }
        if (--this.duration == 0) {
            c.getStats().addPa(1);
            return true;
        }
        return false;
    }
}
