package mmk.model.util;

import mmk.model.item.consumable.AConsumable;
import mmk.model.item.deck.card.ACard;
import mmk.model.item.equipable.enchantment.IEnchantment;
import mmk.model.item.equipable.enchantment.armor.Thorns;
import mmk.model.item.equipable.enchantment.weapon.FireAspect;
import mmk.model.item.equipable.enchantment.weapon.Freezing;

public class Manager {

    public static IEnchantment setDecoratorWeapon(int enchantment, IEnchantment item){
        int i = 1;
        while (enchantment > 0) {
            if ((enchantment & 1) > 0)
                item = setDecorationWeapon(i, item);
            enchantment = enchantment>>i++;
        }
        return item;
    }

    private static IEnchantment setDecorationWeapon(int id, IEnchantment item){
        return switch (id) {
            case 1 -> new FireAspect(item);
            case 2 -> new Freezing(item);
            default -> throw new RuntimeException("pas d'enchantmenet correspondant");
        };

    }

    public static IEnchantment setDecoratorArmor(int enchantment, IEnchantment item){
        int i = 1;
        while (enchantment > 0) {
            if ((enchantment & 1) > 0)
                item = setDecorationArmor(i, item);
            enchantment = enchantment>>i++;
        }
        return item;
    }

    private static IEnchantment setDecorationArmor(int id, IEnchantment item){
        return switch (id) {
            case 1 -> new Thorns(item);
            default -> throw new RuntimeException("pas d'enchantmenet correspondant");
        };
    }


    public static ACard createCard(int id) {
        return switch (id) {
            case 1 -> ACard.REGEN_HP_CARD;
            case 2 -> ACard.PA_PAIR_IMPAIR_CARD;
            case 3 -> ACard.STRENGTH_T2_CARD;
            case 4 -> ACard.STRENGTH_PAIR_CARD;
            case 5 -> ACard.STRENGTH_CARD;
            case 6 -> ACard.STRENGTH_FOR_HEALING_CARD;
            case 7 -> ACard.STRENGTH_IF_HURT_CARD;
            case 8 -> ACard.STRENGTH_BONUS_ATTACK_CARD;
            default -> throw new RuntimeException("pas de carte correspondant");
        };
    }

    public static AConsumable createConsumable(int id) {
        return switch (id) {
            case 22 -> AConsumable.POTION_VIE;
            case 23 -> AConsumable.POTION_PA;
            case 24 -> AConsumable.POTION_CLEANSE;
            default -> throw new RuntimeException("pas de consomable correspondant");
        };
    }
}
