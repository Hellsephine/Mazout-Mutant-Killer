package mmk.model.item;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "inventory")
public class Inventory {

    @Id
    @Column(name = "id_item")
    private Integer idItem;

    @Column(name = "id_character")
    private Integer idCharacter;

    @Column(name = "amount")
    private Integer amount;

    @Column(name = "type")
    private String type;

    public Inventory(int idItem, int idCharacter, int amount, String type) {
        this.idItem = idItem;
        this.idCharacter = idCharacter;
        this.amount = amount;
        this.type = type;
    }

    public Inventory() {}

    public void addAmount() {
        this.amount++;
    }

    public void removeAmount() {
        this.amount--;
    }

    public int getIdItem() {
        return this.idItem;
    }

    public int getAmount() {
        return this.amount;
    }

    public String getType() {
        return this.type;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}
