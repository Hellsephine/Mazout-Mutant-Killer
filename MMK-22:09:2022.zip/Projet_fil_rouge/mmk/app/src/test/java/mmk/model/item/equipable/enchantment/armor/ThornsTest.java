package mmk.model.item.equipable.enchantment.armor;

import mmk.model.item.equipable.armor.Armor;
import mmk.model.item.equipable.enchantment.IEnchantment;
import mmk.model.item.equipable.weapon.Weapon;
import mmk.model.personnage.Character;
import org.junit.jupiter.api.*;

import mmk.model.util.DBConnection;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class ThornsTest {

    @Test
    @DisplayName("creation")
    public void creation() {
        Thorns t = (Thorns) new Armor(1, 1, 1).getIArmor();

        assertNotNull(t);
    }

    @Test
    @DisplayName("cration")
    public void creation_withFireAspectContructor() {
        Armor a = new Armor(1, 1, 0);
        Thorns t = new Thorns(a);

        assertNotNull(t);
    }

    @Test
    @DisplayName("load")
    public void load() {
        IEnchantment ie = DBConnection.SESSION.getReference(Armor.class, 1).getIArmor();

        assertTrue(ie instanceof Thorns);
    }

    @Test
    @DisplayName("persist")
    public void persist() {
        fail("not implemented yet");
    }

    @Test
    @DisplayName("use")
    public void use() {
        ACharacterImplementation c = new ACharacterImplementation();
        Thorns t = (Thorns) new Armor(1, 1, 1).getIArmor();

        int before = c.getHp();
        t.use(c, 10);
        int after = c.getHp();

        assertTrue(before > after);
    }

    private static class ACharacterImplementation extends Character {
        public ACharacterImplementation() {
            super(1,
                    new Weapon(1, 1, 0),
                    new Armor(1, 1, 0),
                    1);
        }
    }
}
