package mmk.model.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.*;

import mmk.model.personnage.monster.Monster;
import mmk.model.world.Board;

public class LootManagerTest {

    
    @BeforeAll
    public static void setUp() {
        DBConnection.init();
    }

    @BeforeEach
    public void beginTransaction() {
        DBConnection.beginTransaction();
    }

    @AfterEach
    public void rollBack() {
        DBConnection.rollBack();
    }

    @AfterAll
    public static void tearDown(){
        DBConnection.close();
    }

    @Test
    public void Test_accesJson_byId(){
//        Monster m = new Monster(1);
//        LootManager.cadavre(m);
//        Board board = new Board(1);
//
//        LootManager.initJsonObject(board);
//        assertEquals(true, LootManager.isQueueOfDeadEmpty());
    }
}
