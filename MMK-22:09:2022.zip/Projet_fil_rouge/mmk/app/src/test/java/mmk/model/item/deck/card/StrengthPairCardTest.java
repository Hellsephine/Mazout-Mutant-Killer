package mmk.model.item.deck.card;

import mmk.model.personnage.hero.Hero;
import mmk.model.util.DBConnection;
import mmk.model.util.Manager;
import mmk.model.util.Vector2;
import mmk.model.world.Board;
import org.hibernate.Transaction;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.assertEquals;


public class StrengthPairCardTest {

    Transaction tx;

    @Test
    @DisplayName("effect once, add 5 strength")
    public void effect_once_addStrength() {
        Hero c = DBConnection.SESSION.find(Hero.class, 1);
        Board board = new Board(3, 2, 1, 1, 1);
        board.addCharacter(c, new Vector2(1, 1));

        Manager.createCard(4).effect(board, 0);

        assertEquals(15, c.getStrength());
    }

    @Test
    @DisplayName("effect twice, nothing")
    public void effect_twice_nothing() {
        Hero c = DBConnection.SESSION.find(Hero.class, 1);
        Board board = new Board(3, 2, 1, 1, 1);
        board.addCharacter(c, new Vector2(1, 1));

        Manager.createCard(4).effect(board, 0);
        Manager.createCard(4).effect(board, 1);

        assertEquals(10, c.getStrength());
    }

    @Test
    @DisplayName("effect three times, add 5 strength")
    public void effect_threeTimes_addStrength() {
        Hero c = DBConnection.SESSION.find(Hero.class, 1);
        Board board = new Board(3, 2, 1, 1, 1);
        board.addCharacter(c, new Vector2(1, 1));

        Manager.createCard(4).effect(board, 0);
        Manager.createCard(4).effect(board, 1);
        Manager.createCard(4).effect(board, 2);

        assertEquals(15, c.getStrength());
    }

    @BeforeEach
    public void beforeEach() {
        tx = DBConnection.SESSION.beginTransaction();
    }

    @AfterEach
    public void afterEach() {
        tx.rollback();
    }
}
