package mmk.model.personnage;

import mmk.model.item.equipable.armor.Armor;
import mmk.model.item.equipable.weapon.Weapon;
import mmk.model.personnage.state.EPersonnageState;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

public class EPersonnageStateTest {

    @Test
    public void addPersonnageState_add1State() {
        ACharacterImplementation c = new ACharacterImplementation();

        c.addPersonnageState(EPersonnageState.BURN, 1);

        assertEquals(EPersonnageState.BURN.value, c.getPersonnageState());
    }

    @Test
    public void addPersonnageState_add2States() {
        ACharacterImplementation c = new ACharacterImplementation();

        c.addPersonnageState(EPersonnageState.BURN, 1);
        c.addPersonnageState(EPersonnageState.BLEEDING, 1);

        assertAll(() -> assertTrue(c.isPersonnageState(EPersonnageState.BURN)),
                () -> assertTrue(c.isPersonnageState(EPersonnageState.BLEEDING)));
    }

    @Test
    public void removePersonnageState() {
        ACharacterImplementation c = new ACharacterImplementation();

        c.addPersonnageState(EPersonnageState.BURN, 4);
        c.addPersonnageState(EPersonnageState.POISON, 5);

        c.removeAllPersonnageState();

        assertEquals(EPersonnageState.NEUTRAL.value, c.getPersonnageState());
    }

    @Test void removePersonnageState_remove1State() {
        ACharacterImplementation c = new ACharacterImplementation();

        c.addPersonnageState(EPersonnageState.BURN, 3);
        c.addPersonnageState(EPersonnageState.POISON, 4);

        c.removePersonnageState(EPersonnageState.POISON);

        assertEquals(EPersonnageState.BURN.value, c.getPersonnageState());
    }

    private static class ACharacterImplementation extends Character {
        public ACharacterImplementation() {
            super(1,
                    new Weapon(1, 1, 0),
                    new Armor(1, 1, 0),
                    1);
        }
    }
}
