package mmk.model.item.equipable;

import mmk.model.item.equipable.armor.Armor;
import mmk.model.item.equipable.armor.StaticArmor;
import mmk.model.item.equipable.weapon.Weapon;
import mmk.model.personnage.Character;
import mmk.model.util.DBConnection;
import org.hibernate.Transaction;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

public class ArmorTest {

    Transaction tx;

    @Test
    @DisplayName("creation new Armor")
    public void creationArmor() {
        Armor a = new Armor(1, 1, 0);

        assertNotNull(a);
    }

    @Test
    @DisplayName("creation of a armor and check if it correspond to the static_armor")
    public void creationArmor_checkIfCorrespondToStaticArmor() {
        Armor a = new Armor(1, 1, 0);

        StaticArmor staticArmor = DBConnection.SESSION.getReference(StaticArmor.class, 1);

        assertAll(() -> assertEquals(staticArmor.getDefence(), a.getDefence()),
                () -> assertEquals(staticArmor.getStaticItem().getName(), a.getName()),
                () -> assertEquals(staticArmor.getStaticItem().getDescription(), a.getDescription()),
                () -> assertEquals(staticArmor.getStaticItem().getIconURL(), a.getIconURL()));
    }

    @Test
    @DisplayName("load a Armor")
    public void loadArmor() {
        Armor a = DBConnection.SESSION.getReference(Armor.class, 1);

        assertNotNull(a);
    }

    @Test
    @DisplayName("load Armor and check the attributes")
    public void loadArmor_checkAttributes() {
        Armor a = DBConnection.SESSION.getReference(Armor.class, 1);

        assertAll(() -> assertNotNull(a.getIArmor()),
                () -> assertNotNull(a.getName()));
    }

    @Test
    @DisplayName("persist armor")
    public void persistArmor() {
        Armor a = new Armor(1, 1, 0);

        int before = DBConnection.SESSION.createQuery("select a from Armor a", Armor.class).getResultList().size();
        DBConnection.SESSION.persist(a);
        int after = DBConnection.SESSION.createQuery("select a from Armor a", Armor.class).getResultList().size();

        assertEquals(before+1, after);
    }

    @Test
    @DisplayName("equipe")
    public void equipe() {
        ACharacterImplementation c = new ACharacterImplementation();
        Armor a = new Armor(1, 1, 0);

        a.equip(c);

        assertEquals(c.getArmor(), a.getIArmor());
    }

    @Test
    @DisplayName("unequipe")
    public void unequipe() {
        ACharacterImplementation c = new ACharacterImplementation();
        Armor a = new Armor(1, 1, 0);

        a.equip(c);
        a.unequip(c);

        assertSame(DBConnection.SESSION.getReference(Armor.class, 1), c.getArmor());
    }

    @Test
    @DisplayName("use")
    public void use() {
        ACharacterImplementation c = new ACharacterImplementation();
        Armor a = new Armor(1, 1, 0);

        int damage = a.use(c, 20);

        assertEquals(20-a.getDefence(), damage);
    }


    private static class ACharacterImplementation extends Character {
        public ACharacterImplementation() {
            super(1,
                    new Weapon(1, 1, 0),
                    new Armor(1, 1, 0),
                    1);
        }
    }

    @BeforeEach
    public void beforeEach() {
        tx = DBConnection.SESSION.beginTransaction();
    }

    @AfterEach
    public void afterEach() {
        tx.rollback();
    }
}
