package mmk.model.world;


import mmk.model.personnage.hero.Hero;
import mmk.model.personnage.monster.Monster;
import mmk.model.util.DBConnection;
import mmk.model.util.Vector2;
import org.hibernate.Transaction;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class BoardTest {

    Transaction tx;

    @Test
    @DisplayName("creation Board")
    public void creationBoard() {
        Board b = new Board(3, 2, 1, 1, 1);

        assertNotNull(b);
    }

    @Test
    @DisplayName("creation board and check the attributes")
    public void creationBoard_checkAttributes() {
        Board b = new Board(3, 2, 1, 1, 1);

        assertAll(() -> assertNotNull(b.getAPersonnageBoard()),
                () -> assertNotNull(b.getBackgroundBoard()),
                () -> assertNotNull(b.getHeros()),
                () -> assertNotNull(b.getMonsters()));
    }

    @Test
    @DisplayName("load board")
    public void loadBoard() {
        Board b = DBConnection.SESSION.getReference(Board.class, 1);

        assertNotNull(b);
    }

    @Test
    @DisplayName("load board and check attributes")
    public void loadBoard_checkAttributes() {
        Board b = DBConnection.SESSION.getReference(Board.class, 1);

        assertAll(() -> assertNotNull(b.getAPersonnageBoard()),
                () -> assertNotNull(b.getBackgroundBoard()),
                () -> assertNotNull(b.getHeros()),
                () -> assertNotNull(b.getMonsters()));
    }

    @Test
    @DisplayName("persist board")
    public void persistBoard() {
        Board b = new Board(3, 2, 1, 1, 1);

        int before = DBConnection.SESSION.createQuery("select b from Board b", Board.class).getResultList().size();
        DBConnection.SESSION.persist(b);
        int after = DBConnection.SESSION.createQuery("select b from Board b", Board.class).getResultList().size();

        assertEquals(before+1, after);
    }

    @Test
    @DisplayName("background to string")
    public void backgroundBoardToString() {
        String background = new Board(3, 2, 1, 1, 1).backgroundBoardToString();

        assertEquals("0,6", background);
    }

    @Test
    @DisplayName("ACharacter to string")
    public void aCharacterBoardToString() {
        Board b = new Board(3, 2, 1, 1, 1);
        b.addCharacter(
                DBConnection.SESSION.getReference(Hero.class, 1),
                new Vector2(1, 1)
        );

        String personage = b.apersonnageBoardToString();

        assertEquals("1,1,1", personage);
    }

    @Test
    @DisplayName("ACharacter to string with no character on the board")
    public void apersonnageBoardToString_noPersonage() {
        Board b = new Board(3, 2, 1, 1, 1);
        String personage = b.apersonnageBoardToString();

        assertEquals("", personage);
    }

    @Test
    @DisplayName("add hero to the board")
    public void addPersonnage_hero() {
        Board b = new Board(3, 2, 1, 1, 1);
        Hero c = DBConnection.SESSION.getReference(Hero.class, 1);

        b.addCharacter(c, new Vector2(1, 1));

        assertAll(() -> assertEquals(1, b.getHeros().length),
                () -> assertSame(c, b.getAPersonnageBoard()[1][1]));
    }

    @Test
    @DisplayName("add monster to the board")
    public void addPersonnage_monster() {
        Board b = new Board(3, 2, 1, 1, 1);
        Monster c = DBConnection.SESSION.getReference(Monster.class, 3);
        b.addCharacter(c, new Vector2(1, 1));

        assertAll(() -> assertEquals(1, b.getMonsters().length),
                () -> assertSame(c, b.getAPersonnageBoard()[1][1]));
    }

    @Test
    @DisplayName("move V2 to V2")
    public void move_V2ToV2() {
        Board b = new Board(3, 2, 1, 1, 1);
        Hero c = DBConnection.SESSION.getReference(Hero.class, 1);
        b.addCharacter(c, new Vector2(1, 1));

        b.move(new Vector2(1, 1), new Vector2(2, 1));

        assertAll(() -> assertNull(b.getAPersonnageBoard()[1][1]),
                () -> assertSame(c, b.getAPersonnageBoard()[1][2]));
    }

    @Test
    @DisplayName("move using direction with the same direction of the personage")
    public void move_direction_sameDirection() {
        Board b = new Board(3, 2, 1, 1, 1);
        Hero c = DBConnection.SESSION.find(Hero.class, 1);
        b.addCharacter(c, new Vector2(1, 1));

        b.move(c, 1);

        assertAll(() -> assertNull(b.getAPersonnageBoard()[1][1]),
                () -> assertSame(c, b.getAPersonnageBoard()[1][2]));
    }

    @Test
    @DisplayName("move using direction with a different direction of the personage")
    public void move_direction_differentDirection() {
        Board b = new Board(3, 2, 1, 1, 1);
        Hero c = DBConnection.SESSION.find(Hero.class, 1);
        b.addCharacter(c, new Vector2(1, 1));

        b.move(c, -1);

        assertAll(() -> assertEquals(new Vector2(-1, 0), c.getDirection()),
                () -> assertSame(c, b.getAPersonnageBoard()[1][1]));
    }

    @Test
    @DisplayName("move using move direction of the personnage")
    public void move_() {
        Board b = new Board(3, 2, 1, 1, 1);
        Hero c = DBConnection.SESSION.find(Hero.class, 1);
        b.addCharacter(c, new Vector2(1, 1));

        b.move(c);

        assertAll(() -> assertNull(b.getAPersonnageBoard()[1][1]),
                () -> assertSame(c, b.getAPersonnageBoard()[1][2]));
    }

    @Test
    @DisplayName("get character position")
    public void getCharacterPosition() {
        Board b = new Board(3, 2, 1, 1, 1);
        Hero c = DBConnection.SESSION.find(Hero.class, 1);
        b.addCharacter(c, new Vector2(1, 1));

        assertEquals(new Vector2(1, 1), b.getApersonnagePosition(c));
    }

    @Test
    @DisplayName("get character at position")
    public void getAtPosition() {
        Board b = new Board(3, 2, 1, 1, 1);
        Hero c = DBConnection.SESSION.getReference(Hero.class, 1);
        b.addCharacter(c, new Vector2(1, 1));

        assertSame(c, b.getAtPosition(new Vector2(1, 1)));
    }


    @BeforeEach
    public void beforeEach() {
        tx = DBConnection.SESSION.beginTransaction();
    }

    @AfterEach
    public void afterEach() {
        tx.rollback();
    }
}
