package mmk.model.item.deck.card;

import mmk.model.personnage.hero.Hero;
import mmk.model.util.DBConnection;
import mmk.model.util.Manager;
import mmk.model.util.Vector2;
import mmk.model.world.Board;
import org.hibernate.Transaction;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class StrengthIfHurtCardTest {

    Transaction tx;

    @Test
    @DisplayName("effect while maxHp, nothing change")
    public void effect_effectMaxHp_Nothing() {
        Hero c = DBConnection.SESSION.getReference(Hero.class, 1);
        Board board = new Board(3, 2, 1, 1, 1);
        board.addCharacter(c, new Vector2(1, 1));

        Manager.createCard(7).effect(board, 0);

        assertEquals(10, c.getStrength());
    }

    @Test
    @DisplayName("effect while hp < maxHp/2, add 5 strength")
    public void effect_effectLess50percent_add5Strength() {
        Hero c = DBConnection.SESSION.getReference(Hero.class, 1);
        Board board = new Board(3, 2, 1, 1, 1);
        board.addCharacter(c, new Vector2(1, 1));

        c.removeHp(80);
        Manager.createCard(7).effect(board, 0);

        assertEquals(15, c.getStrength());
    }

    @BeforeEach
    public void beforeEach() {
        tx = DBConnection.SESSION.beginTransaction();
    }

    @AfterEach
    public void afterEach() {
        tx.rollback();
    }
}
