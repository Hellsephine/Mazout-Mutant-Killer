package mmk.model.personnage.monster;

import mmk.model.item.equipable.armor.Armor;
import mmk.model.item.equipable.weapon.Weapon;
import mmk.model.personnage.StaticCharacter;
import mmk.model.util.DBConnection;

import org.hibernate.Transaction;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;


public class MonsterTest {

    Transaction tx;

    @Test
    @DisplayName("creation of a monster")
    public void creationMonster() {
        Monster m = new Monster(1,
                new Weapon(1, 1, 0),
                new Armor(1, 1, 0),
                1
        );

        assertNotNull(m);
    }

    @Test
    @DisplayName("creation of a monster and check if it correspond to the static_personage")
    public void creationMonster_checkIdCorrespondToStaticCharacter() {
        Monster m = new Monster(1,
                new Weapon(1, 1, 0),
                new Armor(1, 1, 0),
                1
        );
        StaticCharacter staticCharacter = DBConnection.SESSION.getReference(StaticCharacter.class, 1);

        assertAll(() -> assertEquals(staticCharacter.getName(), m.getName()),
                () -> assertEquals(staticCharacter.getDescription(), m.getDescription()),
                () -> assertEquals(staticCharacter.getPa(), m.getPa()),
                () -> assertEquals(staticCharacter.getPm(), m.getPm()),
                () -> assertEquals(staticCharacter.getMaxHp(), m.getMaxHp()),
                () -> assertEquals(staticCharacter.getStrength(), m.getStrength()));
    }

    @Test
    @DisplayName("Load a monster")
    public void loadMonster() {
        Monster m = DBConnection.SESSION.getReference(Monster.class, 3);

        assertNotNull(m);
    }

    @Test
    @DisplayName("persist a monster")
    public void persistMonster() {
        Monster m = new Monster(1,
                new Weapon(1, 1, 0),
                new Armor(1, 1, 0),
                1
        );

        int before = DBConnection.SESSION.createQuery("select m from Monster m", Monster.class).getResultList().size();
        DBConnection.SESSION.persist(m);
        int after = DBConnection.SESSION.createQuery("select m from Monster m", Monster.class).getResultList().size();

        assertEquals(before+1, after);

    }



    @BeforeEach
    public void beforeEach() {
        tx = DBConnection.SESSION.beginTransaction();
    }
    @AfterEach
    public void afterEach() {
        tx.rollback();
    }

}
