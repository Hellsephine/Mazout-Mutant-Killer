package mmk.model.item.consumable;

import mmk.model.item.equipable.armor.Armor;
import mmk.model.item.equipable.weapon.Weapon;
import mmk.model.personnage.hero.Hero;
import mmk.model.util.DBConnection;
import mmk.model.util.Manager;
import org.hibernate.Transaction;
import org.junit.jupiter.api.*;

import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.*;

public class PotionPATest {

    Transaction tx;

    @Test
    public void consume(){
        HeroImplementation c = new HeroImplementation();
        PotionPA p = (PotionPA) Manager.createConsumable(23);

        int before = c.getPa();
        c.addConsumable(p);
        c.consume(p.getId());
        int after = c.getPa();


        assertTrue(before < after);
    }


    private static class HeroImplementation extends Hero {
        public HeroImplementation() {
            super(1,
                    new Weapon(1, 1, 0),
                    new Armor(1, 1, 0),
                    new HashMap<>(), new HashMap<>()
            );
        }
    }


    @BeforeEach
    public void beforeEach() {
        tx = DBConnection.SESSION.beginTransaction();
    }
    @AfterEach
    public void afterEach() {
        tx.rollback();
    }
}
