package mmk.model.item.deck.card;

import mmk.model.personnage.hero.Hero;
import mmk.model.util.DBConnection;
import mmk.model.util.Manager;
import mmk.model.util.Vector2;
import mmk.model.world.Board;
import org.hibernate.Transaction;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class StrengthForHealingCardTest {

    Transaction tx;

    @Test
    @DisplayName("effect once nothing")
    public void effect_once() {
        Hero c = DBConnection.SESSION.getReference(Hero.class, 1);
        Board board = new Board(3, 2, 1, 1, 1);
        board.addCharacter(c, new Vector2(1, 1));

        c.addStrength(50);
        c.removeHp(80);
        int before = c.getHp();
        Manager.createCard(6).effect(board, 0);

        assertEquals(before, c.getHp());
    }

    @Test
    @DisplayName("effect twice add 2 hp")
    public void effect_twice() {
        Hero c = DBConnection.SESSION.getReference(Hero.class, 1);
        Board board = new Board(3, 2, 1, 1, 1);
        board.addCharacter(c, new Vector2(1, 1));

        c.addStrength(50);
        c.removeHp(80);
        int before = c.getHp();
        Manager.createCard(6).effect(board, 0);
        Manager.createCard(6).effect(board, 1);

        assertEquals(before+2, c.getHp());
    }

    @BeforeEach
    public void beforeEach() {
        tx = DBConnection.SESSION.beginTransaction();
    }

    @AfterEach
    public void afterEach() {
        tx.rollback();
    }

}
