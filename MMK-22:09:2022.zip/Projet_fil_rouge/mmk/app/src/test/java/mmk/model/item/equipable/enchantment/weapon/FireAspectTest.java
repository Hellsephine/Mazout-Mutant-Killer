package mmk.model.item.equipable.enchantment.weapon;

import mmk.model.item.equipable.armor.Armor;
import mmk.model.item.equipable.enchantment.IEnchantment;
import mmk.model.item.equipable.weapon.Weapon;
import mmk.model.personnage.Character;
import mmk.model.personnage.state.EPersonnageState;
import org.junit.jupiter.api.*;

import mmk.model.util.DBConnection;

import static org.junit.jupiter.api.Assertions.*;

public class FireAspectTest {

    @Test
    @DisplayName("creation")
    public void creation() {
        FireAspect fa = (FireAspect) new Weapon(1, 1, 1).getIWeapon();

        assertNotNull(fa);
    }

    @Test
    @DisplayName("cration")
    public void creation_withFireAspectContructor() {
        Weapon w = new Weapon(1, 1, 0);
        FireAspect fa = new FireAspect(w);

        assertNotNull(fa);
    }

    @Test
    @DisplayName("load")
    public void load() {
        IEnchantment ie = DBConnection.SESSION.getReference(Weapon.class, 1).getIWeapon();

        assertTrue(((AEnchantmentWeapon)ie).getEquipable() instanceof  FireAspect);
    }

    @Test
    @DisplayName("persist")
    public void persist() {
        fail("not implemented yet");
    }

    @Test
    @DisplayName("use")
    public void use() {
        ACharacterImplementation c = new ACharacterImplementation();
        FireAspect fa = (FireAspect) new Weapon(1, 1, 1).getIWeapon();
        fa.use(c, 0);

        assertTrue(c.isPersonnageState(EPersonnageState.BURN));
    }

    private static class ACharacterImplementation extends Character {
        public ACharacterImplementation() {
            super(1,
                    new Weapon(1, 1, 0),
                    new Armor(1, 1, 0),
                    1);
        }
    }
}
