package mmk.model.personnage;

import static org.junit.jupiter.api.Assertions.*;

import mmk.model.item.equipable.armor.Armor;
import mmk.model.item.equipable.weapon.Weapon;
import mmk.model.personnage.hero.Hero;
import mmk.model.personnage.monster.Monster;
import mmk.model.util.DBConnection;
import mmk.model.util.Vector2;
import mmk.model.world.Board;
import org.hibernate.Transaction;
import org.junit.jupiter.api.*;


public class APersonnageTest {

    Transaction tx;

    @Test
    @DisplayName("is dead not dead")
    public void isDead_notDead() {
        ACharacterImplementation c = new ACharacterImplementation();

        assertFalse(c.isDead());
    }

    @Test
    @DisplayName("is dead not dead")
    public void isDead_Dead() {
        ACharacterImplementation c = new ACharacterImplementation();

        c.setHp(0);

        assertTrue(c.isDead());
    }

    @Test
    @DisplayName("attack")
    public void attack() {
        Hero c = DBConnection.SESSION.find(Hero.class, 1);
        Monster m = DBConnection.SESSION.find(Monster.class, 3);
        Board b = new Board(3, 2, 1, 1, 1);
        b.addCharacter(c, new Vector2(1, 1));
        b.addCharacter(m, new Vector2(2, 1));

        int before = m.getHp();
        c.attack(b);

        assertTrue(before > m.getHp());
    }

    @Test
    @DisplayName("get in range with no one in range")
    public void getInRange_noOneInRange() {
        Hero c = DBConnection.SESSION.find(Hero.class, 1);
        Board b = new Board(3, 2, 1, 1, 1);
        b.addCharacter(c, new Vector2(2, 1));

        Character p = c.getInRange(b);

        assertNull(p);
    }

    @Test
    @DisplayName("get in range with someone in range")
    public void getInRange_someoneInRange() {
        Hero c = DBConnection.SESSION.find(Hero.class, 1);
        Monster m = DBConnection.SESSION.find(Monster.class, 3);
        Board b = new Board(3, 2, 1, 1, 1);
        b.addCharacter(c, new Vector2(1, 1));
        b.addCharacter(m, new Vector2(2, 1));

        Character p = c.getInRange(b);

        assertSame(m, p);
    }

    @Test
    @DisplayName("take damage")
    public void takeDamage() {
        ACharacterImplementation c = new ACharacterImplementation();
        ACharacterImplementation c2 = new ACharacterImplementation();

        int before = c.getHp();
        c.takeDomage(c2, 20);
        int after = c.getHp();

        assertTrue(before > after);
    }

    private static class ACharacterImplementation extends Character {
        public ACharacterImplementation() {
            super(1,
                    new Weapon(1, 1, 0),
                    new Armor(1, 1, 0),
                    1);
        }
    }


    @BeforeEach
    public void beforeEach() {
        tx = DBConnection.SESSION.beginTransaction();
    }

    @AfterEach
    public void afterEach() {
        tx.rollback();
    }

}
