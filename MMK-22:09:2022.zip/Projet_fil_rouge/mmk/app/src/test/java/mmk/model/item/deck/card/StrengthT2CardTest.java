package mmk.model.item.deck.card;

import mmk.model.personnage.hero.Hero;
import mmk.model.util.DBConnection;
import mmk.model.util.Manager;
import mmk.model.util.Vector2;
import mmk.model.world.Board;
import org.hibernate.Transaction;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class StrengthT2CardTest {

    Transaction tx;

    @Test
    @DisplayName("effect once, add 5 strength")
    public void effect_effectTour1_addForce() {
        Hero c = DBConnection.SESSION.find(Hero.class, 1);
        Board board = new Board(3, 2, 1, 1, 1);
        board.addCharacter(c, new Vector2(1, 1));

        Manager.createCard(3).effect(board, 0);

        assertEquals(15, c.getStrength());
    }

    @Test
    public void effect_twice_normalForce() {
        Hero c = DBConnection.SESSION.find(Hero.class, 1);
        Board board = new Board(3, 2, 1, 1, 1);
        board.addCharacter(c, new Vector2(1, 1));

        Manager.createCard(3).effect(board, 0);
        Manager.createCard(3).effect(board, 1);
        Manager.createCard(3).effect(board, 2);

        assertEquals(10, c.getStrength());
    }

    @BeforeEach
    public void beforeEach() {
        tx = DBConnection.SESSION.beginTransaction();
    }

    @AfterEach
    public void afterEach() {
        tx.rollback();
    }
}
