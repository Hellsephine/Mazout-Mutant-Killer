package mmk.model.item.deck.card;

import mmk.model.personnage.hero.Hero;
import mmk.model.util.DBConnection;
import mmk.model.util.Manager;
import mmk.model.util.Vector2;
import mmk.model.world.Board;
import org.hibernate.Transaction;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class StrengthCardTest {

    Transaction tx;

    @Test
    @DisplayName("effect once, add 5 strength")
    public void effect_once() {
        Hero c = DBConnection.SESSION.getReference(Hero.class, 1);
        Board board = new Board(3, 2, 1, 1, 1);
        board.addCharacter(c, new Vector2(1, 1));

        int before = c.getStrength();
        Manager.createCard(5).effect(board, 0);

        assertEquals(before+5, c.getStrength());
    }

    @Test
    @DisplayName("effect twice, add 10 strength")
    public void effect_twice() {
        Hero c = DBConnection.SESSION.getReference(Hero.class, 1);
        Board board = new Board(3, 2, 1, 1, 1);
        board.addCharacter(c, new Vector2(1, 1));

        int before = c.getStrength();
        Manager.createCard(5).effect(board, 0);
        Manager.createCard(5).effect(board, 1);

        assertEquals(before+10, c.getStrength());
    }


    @BeforeEach
    public void beforeEach() {
        tx = DBConnection.SESSION.beginTransaction();
    }

    @AfterEach
    public void afterEach() {
        tx.rollback();
    }
}
