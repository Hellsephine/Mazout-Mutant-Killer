package mmk.model.item.deck.card;

import mmk.model.personnage.hero.Hero;
import mmk.model.util.DBConnection;
import mmk.model.util.Manager;
import mmk.model.util.Vector2;
import mmk.model.world.Board;
import org.hibernate.Transaction;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class RegenHpCardTest {

    Transaction tx;

    @Test
    @DisplayName("effect while max hp, nothing change")
    public void effect_effectWithMaxHp_nothing() {
        Hero c = DBConnection.SESSION.getReference(Hero.class, 1);
        Board board = new Board(3, 2, 1, 1, 1);
        board.addCharacter(c, new Vector2(1, 1));

        int before = c.getHp();
        Manager.createCard(1).effect(board, 0);

        assertEquals(before, c.getHp());
    }

    @Test
    @DisplayName("effect while below 30% hp, gain hp")
    public void effect_effectWithLessHp_gainHp() {
        Hero c = DBConnection.SESSION.getReference(Hero.class, 1);
        Board board = new Board(3, 2, 1, 1, 1);
        board.addCharacter(c, new Vector2(1, 1));

        c.removeHp(80);

        Manager.createCard(1).effect(board, 0);

        assertTrue(c.getHp() > 30);
    }

    @BeforeEach
    public void beforeEach() {
        tx = DBConnection.SESSION.beginTransaction();
    }

    @AfterEach
    public void afterEach() {
        tx.rollback();
    }
}
