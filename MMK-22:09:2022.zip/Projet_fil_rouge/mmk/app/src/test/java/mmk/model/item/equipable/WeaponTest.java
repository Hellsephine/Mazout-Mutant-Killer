package mmk.model.item.equipable;

import mmk.model.item.equipable.armor.Armor;
import mmk.model.item.equipable.weapon.StaticWeapon;
import mmk.model.item.equipable.weapon.Weapon;
import mmk.model.personnage.Character;
import org.hibernate.Transaction;
import org.junit.jupiter.api.*;

import mmk.model.util.DBConnection;

import static org.junit.jupiter.api.Assertions.*;

public class WeaponTest {

    Transaction tx;

    @Test
    @DisplayName("creation new Weapon")
    public void creationWeapon() {
        Weapon w = new Weapon(1, 1, 0);

        assertNotNull(w);
    }

    @Test
    @DisplayName("creation of a Weapon and check if it correspond to the static_Weapon")
    public void creationWeapon_checkIfCorrespondToStaticWeapon() {
        Weapon w = new Weapon(1, 1, 0);

        StaticWeapon staticWeapon = DBConnection.SESSION.getReference(StaticWeapon.class, 1);

        assertAll(() -> assertEquals(staticWeapon.getDamage(), w.getDamage()),
                () -> assertEquals(staticWeapon.getMinRange(), w.getMinRange()),
                () -> assertEquals(staticWeapon.getMaxRange(), w.getMaxRange()),
                () -> assertEquals(staticWeapon.getStaticItem().getName(), w.getName()),
                () -> assertEquals(staticWeapon.getStaticItem().getDescription(), w.getDescription()),
                () -> assertEquals(staticWeapon.getStaticItem().getIconURL(), w.getIconURL()));
    }

    @Test
    @DisplayName("load a Weapon")
    public void loadWeapon() {
        Weapon w = DBConnection.SESSION.getReference(Weapon.class, 1);

        assertNotNull(w);
    }

    @Test
    @DisplayName("load Weapon and check the attributes")
    public void loadWeapon_checkAttributes() {
        Weapon w = DBConnection.SESSION.getReference(Weapon.class, 1);

        assertAll(() -> assertNotNull(w.getIWeapon()),
                () -> assertNotNull(w.getName()));
    }

    @Test
    @DisplayName("persist Weapon")
    public void persistWeapon() {
        Weapon w = new Weapon(1, 1, 0);

        int before = DBConnection.SESSION.createQuery("select w from Weapon w", Weapon.class).getResultList().size();
        DBConnection.SESSION.persist(w);
        int after = DBConnection.SESSION.createQuery("select w from Weapon w", Weapon.class).getResultList().size();

        assertEquals(before+1, after);
    }

    @Test
    @DisplayName("equipe")
    public void equipe() {
        ACharacterImplementation c = new ACharacterImplementation();
        Weapon w = new Weapon(1, 1, 0);

        w.equip(c);

        assertEquals(c.getWeapon(), w.getIWeapon());
    }

    @Test
    @DisplayName("unequipe")
    public void unequipe() {
        ACharacterImplementation c = new ACharacterImplementation();
        Weapon w = new Weapon(1, 1, 0);

        w.equip(c);
        w.unequip(c);

        assertSame(DBConnection.SESSION.getReference(Weapon.class, 1), c.getWeapon());
    }

    @Test
    @DisplayName("use")
    public void use() {
        ACharacterImplementation c = new ACharacterImplementation();
        Weapon w = new Weapon(1, 1, 0);

        int damage = w.use(c, 20);

        assertEquals(20+w.getDamage(), damage);
    }


    private static class ACharacterImplementation extends Character {
        public ACharacterImplementation() {
            super(1,
                    new Weapon(1, 1, 0),
                    new Armor(1, 1, 0),
                    1);
        }
    }

    @BeforeEach
    public void beforeEach() {
        tx = DBConnection.SESSION.beginTransaction();
    }

    @AfterEach
    public void afterEach() {
        tx.rollback();
    }
}
