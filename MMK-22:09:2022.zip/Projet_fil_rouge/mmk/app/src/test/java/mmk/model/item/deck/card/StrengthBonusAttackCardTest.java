package mmk.model.item.deck.card;

import mmk.model.personnage.hero.Hero;
import mmk.model.util.DBConnection;
import mmk.model.util.Manager;
import mmk.model.util.Vector2;
import mmk.model.world.Board;
import org.hibernate.Transaction;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class StrengthBonusAttackCardTest {

    Transaction tx;

    @Test
    @DisplayName("effect add one PA because strength > 20")
    public void effect_addPa() {
        Hero c = DBConnection.SESSION.getReference(Hero.class, 1);
        Board board = new Board(3, 2, 1, 1, 1);
        board.addCharacter(c, new Vector2(1, 1));

        c.addStrength(21);
        Manager.createCard(8).effect(board, 0);

        assertEquals(2, c.getPa());
    }

    @Test
    @DisplayName("effect nothing because strength < 20")
    public void effect_nothing() {
        Hero c = DBConnection.SESSION.getReference(Hero.class, 1);
        Board board = new Board(3, 2, 1, 1, 1);
        board.addCharacter(c, new Vector2(1, 1));

        c.removeStrength(c.getStrength());
        Manager.createCard(8).effect(board, 0);

        assertEquals(1, c.getPa());
    }

    @BeforeEach
    public void beforeEach() {
        tx = DBConnection.SESSION.beginTransaction();
    }

    @AfterEach
    public void afterEach() {
        tx.rollback();
    }
}
