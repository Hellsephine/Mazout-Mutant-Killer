package mmk.model.personnage.hero;


import mmk.model.item.equipable.armor.Armor;
import mmk.model.item.equipable.weapon.Weapon;
import mmk.model.personnage.StaticCharacter;
import mmk.model.util.DBConnection;

import mmk.model.util.Manager;
import org.hibernate.Transaction;
import org.junit.jupiter.api.*;

import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.*;


public class HeroTest {

    Transaction tx;

    @Test
    @DisplayName("creation of a hero")
    public void creationHero() {
        Hero h = new Hero(1,
                new Weapon(1, 1, 0),
                new Armor(1, 1, 0),
                new HashMap<>(), new HashMap<>()
        );

        assertNotNull(h);
    }

    @Test
    @DisplayName("creation of a hero and check if it correspond to the static_personage")
    public void creationHero_checkIdCorrespondToStaticCharacter() {
        Hero h = new Hero(1,
                new Weapon(1, 1, 0),
                new Armor(1, 1, 0),
                new HashMap<>(), new HashMap<>()
        );
        StaticCharacter staticCharacter = DBConnection.SESSION.getReference(StaticCharacter.class, 1);

        assertAll(() -> assertEquals(staticCharacter.getName(), h.getName()),
                () -> assertEquals(staticCharacter.getDescription(), h.getDescription()),
                () -> assertEquals(staticCharacter.getPa(), h.getPa()),
                () -> assertEquals(staticCharacter.getPm(), h.getPm()),
                () -> assertEquals(staticCharacter.getMaxHp(), h.getMaxHp()),
                () -> assertEquals(staticCharacter.getStrength(), h.getStrength()));
    }

    @Test
    @DisplayName("Create a hero with consumable")
    public void creationHero_withConsumable() {
        HashMap<Integer, Integer> consumables = new HashMap<>();
        consumables.put(22, 2);
        consumables.put(23, 2);
        Hero h = new Hero(1,
                new Weapon(1, 1, 0),
                new Armor(1, 1, 0),
                new HashMap<>(), consumables
        );

        assertAll(() -> assertEquals(2, h.getConsumables().size()),
                () -> assertTrue(h.getConsumables().containsKey(Manager.createConsumable(22))),
                () -> assertEquals(2, h.getConsumables().get(Manager.createConsumable(22)))
        );
    }

    @Test
    @DisplayName("create a hero with deck")
    public void creationHero_withDeck() {
        HashMap<Integer, Integer> deck = new HashMap<>();
        deck.put(1, 1);
        deck.put(2, 1);
        Hero h = new Hero(1,
                new Weapon(1, 1, 0),
                new Armor(1, 1, 0),
                deck, new HashMap<>()
        );

        assertEquals(2, h.getDeck().getCards().length);
    }

    @Test
    @DisplayName("Load a hero")
    public void loadHero() {
        Hero h = DBConnection.SESSION.getReference(Hero.class, 1);

        assertNotNull(h);
    }

    @Test
    @DisplayName("load a hero and check the attributes")
    public void loadHero_checkTheAttributes() {
        Hero h = DBConnection.SESSION.getReference(Hero.class, 1);

        assertAll(() -> assertNotNull(h.getConsumables()),
                () -> assertNotNull(h.getDeck()));
    }

    @Test
    @DisplayName("load a hero with consumable")
    public void loadHero_withConsumable() {
        Hero h = DBConnection.SESSION.getReference(Hero.class, 1);

        assertAll(() -> assertEquals(3, h.getConsumables().size()),
                () -> assertTrue(h.getConsumables().containsKey(Manager.createConsumable(22))),
                () -> assertEquals(15, h.getConsumables().get(Manager.createConsumable(22)))
        );
    }

    @Test
    @DisplayName("load a hero with cards")
    public void loadHero_withCards() {
        Hero h = DBConnection.SESSION.getReference(Hero.class, 1);

        assertEquals(3, h.getDeck().getCards().length);
    }

    @Test
    @DisplayName("persist a hero")
    public void persistHero() {
        Hero h = new Hero(1,
                new Weapon(1, 1, 0),
                new Armor(1, 1, 0),
                new HashMap<>(), new HashMap<>()
        );

        int before = DBConnection.SESSION.createQuery("select h from Hero h", Hero.class).getResultList().size();
        DBConnection.SESSION.persist(h);
        int after = DBConnection.SESSION.createQuery("select h from Hero h", Hero.class).getResultList().size();

        assertEquals(before+1, after);

    }

    @Test
    @DisplayName("consume")
    public void consume() {
        HashMap<Integer, Integer> consumables = new HashMap<>();
        consumables.put(22, 1);
        Hero h = new Hero(1,
                new Weapon(1, 1, 0),
                new Armor(1, 1, 0),
                new HashMap<>(), consumables
        );

        int before = h.getConsumables().get(Manager.createConsumable(22));
        h.consume(22);
        int after = h.getConsumables().get(Manager.createConsumable(22));

        assertEquals(before-1, after);
    }


    @BeforeEach
    public void beforeEach() {
        tx = DBConnection.SESSION.beginTransaction();
    }
    @AfterEach
    public void afterEach() {
        tx.rollback();
    }

}
