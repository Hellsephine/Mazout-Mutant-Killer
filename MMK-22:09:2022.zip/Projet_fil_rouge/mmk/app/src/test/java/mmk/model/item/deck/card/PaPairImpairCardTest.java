package mmk.model.item.deck.card;

import mmk.model.personnage.hero.Hero;
import mmk.model.util.DBConnection;
import mmk.model.util.Manager;
import mmk.model.util.Vector2;
import mmk.model.world.Board;
import org.hibernate.Transaction;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class PaPairImpairCardTest {

    Transaction tx;

    @Test
    @DisplayName("effect gain a pa")
    public void effect_getAPa() {
        Hero c = DBConnection.SESSION.find(Hero.class, 1);
        Board board = new Board(3, 2, 1, 1, 1);
        board.addCharacter(c, new Vector2(1, 1));

        Manager.createCard(2).effect(board, 0);

        assertEquals(2, c.getPa());
    }

    @Test
    @DisplayName("effect twice nothing change")
    public void effect_nothingChange() {
        Hero c = DBConnection.SESSION.find(Hero.class, 1);
        Board board = new Board(3, 2, 1, 1, 1);
        board.addCharacter(c, new Vector2(1, 1));


        Manager.createCard(2).effect(board, 0);
        Manager.createCard(2).effect(board, 1);

        assertEquals(1, c.getPa());
    }

    @BeforeEach
    public void beforeEach() {
        tx = DBConnection.SESSION.beginTransaction();
    }

    @AfterEach
    public void afterEach() {
        tx.rollback();
    }
}
